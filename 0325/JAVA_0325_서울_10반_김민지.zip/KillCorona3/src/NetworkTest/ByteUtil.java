//package chapter16.login;
package NetworkTest;
public class ByteUtil {
	public static void fillByte(int data, byte[] buf, int offset) throws Exception{
		if(buf ==null){
			throw new Exception("buf 배열이 null 입니다.");
		}
		if (buf.length< offset+4){
			throw new Exception("buf 배열이 size가 부족합니다.");
		}
		for (int i=0, j=3; i<4; i++, j--) {
			buf[i+offset] = (byte)(data>>> (8*j));
		}
	}
	public static void fillByte(byte[] src, int offset, byte[] fill) throws Exception{
		if(src ==null){
			throw new Exception("src 배열이 null 입니다.");
		}
		if(fill ==null){
			throw new Exception("fill 배열이 null 입니다.");
		}
		int len = fill.length;
		if(src.length < len+offset){
			throw new Exception("src 배열이 size가 부족합니다.");
		}
		for (int i = 0; i <len; i++) {
			src[i+offset] = fill[i];
		}
	}
	public static int getInt(byte[] buf, int offset) throws Exception{
		if(buf ==null){
			throw new Exception("buf 배열이 null 입니다.");
		}
		if (buf.length< offset+4){
			throw new Exception("buf 배열이 size가 부족합니다.");
		}
		int data =0;
		for (int i=0, j=3; i<4; i++, j--) {
			 data += (buf[i+offset]&255)<< (8*j);
		}
		return data;
	}
	public static void main(String[] args) throws Exception {
		byte[] id = "kdgfox".getBytes();
		byte[] password = "1111".getBytes();
		int idLen = id.length;
		int pwLen = password.length;
		byte[] buf = new byte[16+idLen+pwLen];
		int total = idLen+pwLen+8;
		int offset = 0;
		ByteUtil.fillByte(1024, buf, offset);
		offset+=4;
		ByteUtil.fillByte(total, buf, offset);
		offset+=4;
		ByteUtil.fillByte(idLen, buf, offset);
		offset+=4;
		ByteUtil.fillByte(buf, offset, id);
		offset+=idLen;
		ByteUtil.fillByte(pwLen, buf, offset);
		offset+=4;
		ByteUtil.fillByte(buf, offset, password);
		
		offset = 0;
		System.out.println(ByteUtil.getInt(buf, offset));
		offset+=4;
		System.out.println(ByteUtil.getInt(buf, offset));
		offset+=4;
		int size = ByteUtil.getInt(buf, offset);
		System.out.println(size);
		offset+=4;
		System.out.println(new String(buf, offset, size));
		offset+=size;
		int pwsize = ByteUtil.getInt(buf, offset);
		System.out.println(pwsize);
		offset+=4;
		System.out.println(new String(buf, offset, pwsize));
	}
}










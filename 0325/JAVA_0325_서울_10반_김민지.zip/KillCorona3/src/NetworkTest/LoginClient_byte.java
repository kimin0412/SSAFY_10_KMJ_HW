//package chapter16.login;
package NetworkTest;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Scanner;
public class LoginClient_byte implements LoginProtocal {
	public static void main(String[] args) {
		Socket s = null;
		Scanner scanner = new Scanner(System.in);
		DataInputStream dis = null;
		DataOutputStream dos = null;
		boolean isRun = true;
		String host="70.12.116.190";
		int port = 7654;
		try {
			s = new Socket(host, port);
			dis = new DataInputStream(s.getInputStream());
			dos = new DataOutputStream(s.getOutputStream());
			int command = 0;
			byte[] buf = null;
			byte[] header = new byte[8];
			byte[] response = null;
			int result = 0;
			int offset = 0;
			int total = 0;
			while (isRun) {
				System.out.println("1. 로그인");
				System.out.println("2. 로그아웃");
				System.out.println("수행할 명령을 숫자로 입력하세요.");
				command = scanner.nextInt();
				switch (command) {
				case LOGIN:
					System.out.println("아이디를 입력하세요");
					byte[] id = scanner.next().getBytes();
					System.out.println("비밀번호를 입력하세요");
					byte[] password = scanner.next().getBytes();
					int idLen = id.length;
					int pwLen = password.length;
					total = ID_LEN+PASSWORD_LEN+idLen + pwLen ;
					buf = new byte[COMMAND+TOTAL+total];
					offset = 0;
					ByteUtil.fillByte(LOGIN, buf, offset);
					offset += COMMAND;
					ByteUtil.fillByte(total, buf, offset);
					offset += TOTAL;
					ByteUtil.fillByte(idLen, buf, offset);
					offset += ID_LEN;
					ByteUtil.fillByte(buf, offset, id);
					offset += idLen;
					ByteUtil.fillByte(pwLen, buf, offset);
					offset += PASSWORD_LEN;
					ByteUtil.fillByte(buf, offset, password);
					dos.write(buf);
					dis.readFully(header);
					
					offset = 0;
					result = ByteUtil.getInt(header, offset);
					offset += COMMAND;
					total = ByteUtil.getInt(header, offset);
					response = new byte[total];
					dis.readFully(response);
					
					String msg = new String(response, 0, total);
					System.out.println(msg);
					break;
				case LOGOUT:
					buf = new byte[8];
					offset = 0;
					ByteUtil.fillByte(LOGOUT, buf, offset);
					offset += 4;
					ByteUtil.fillByte(0, buf, offset);
					dos.write(buf);
					isRun = true;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			IoUtil.close(dis);
			IoUtil.close(dos);
			IoUtil.close(s);
			IoUtil.close(scanner);
		}
	}
}


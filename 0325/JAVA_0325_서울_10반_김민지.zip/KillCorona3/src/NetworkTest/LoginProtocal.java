package NetworkTest;

public interface LoginProtocal {
	int LOGIN=1;
	int LOGOUT=2;
	int LOGIN_FAIL=3;
	int LOGIN_SUCCESS=4;
	int COMMAND=4;
	int TOTAL=4;
	int ID_LEN=4;
	int PASSWORD_LEN=4;
}

//package chapter16.login;
package NetworkTest;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

class LoginService_byte extends Thread implements LoginProtocal{
	private Socket s;
	private DataInputStream dis;
	private DataOutputStream dos;
	private boolean isRun = true;
	private String id;
	public LoginService_byte(Socket s) {
		this.s = s;
	}
	
	public void run(){
		try {
			dis = new DataInputStream(s.getInputStream());
			dos = new DataOutputStream(s.getOutputStream());
			byte[] header 	= new byte[8];
			byte[] data		= null;
			int command		= 0;
			int total		= 0;
			while(isRun){
				dis.readFully(header);    //header만 읽기
				command  = ByteUtil.getInt(header, 0);
				total	 = ByteUtil.getInt(header, COMMAND); //데이타 크기
				if(total>0){ //데이타가 없는 command도 있으므로 
					data 	 = new byte[total];
					dis.readFully(data);
				}
				try{
					switch (command) {
					case LOGIN:
						login(data);
						break;
					case LOGOUT:
						isRun = false;
						System.out.printf("%s님 로그 아웃....", id);
						break;
					}
				}catch(Exception e){
					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			IoUtil.close(dos);
			IoUtil.close(dis);
			IoUtil.close(s);
		}
	}
	private void login(byte[] data) throws Exception{
		int offset			= 0;
		int resultCommand	= 0;
		byte[] response 	= null;
		
		int id_len 	= ByteUtil.getInt(data, offset);
		offset		+= ID_LEN;
		String id	= new String(data, offset, id_len);
		offset		+= id_len;
		int pw_len	= ByteUtil.getInt(data, offset);
		offset		+= PASSWORD_LEN;
		String pw	= new String(data, offset, pw_len);
		
		System.out.printf("LOGIN   id:%s   pw:%s", id, pw);
		String msg	= null;
		if(id.equals("mulcam")){
			if(pw.equals("1111")){
				resultCommand = LOGIN_SUCCESS;
				msg=String.format("%s login success", id);
				this.id = id;
			}else{
				resultCommand = LOGIN_FAIL;
				msg="invalid password";
			}
		}else{
			resultCommand = LOGIN_FAIL;
			msg="invalid id";
		}
		byte[] msgByte 	= msg.getBytes();
		int msgLen		= msgByte.length;
		System.out.println("msg....."+msg+" msgLen:"+msgLen);
		//클라이언트에 전송할 배열 생성 
		response = new byte[COMMAND+TOTAL+msgLen];  
		offset = 0;
		ByteUtil.fillByte(resultCommand, response,offset);
		offset += COMMAND;
		ByteUtil.fillByte(msgLen, response, offset);
		offset += TOTAL;
		ByteUtil.fillByte(response, offset, msgByte);
		
		dos.write(response);
	}
} 
public class LoginServer_byte {
	public static void main(String[] args) {
		ServerSocket ss = null;
		try {
			ss = new ServerSocket(7654);
			System.out.println("LoginServer_byte  running...");
			while(true){
				new LoginService_byte( ss.accept()).start();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			IoUtil.close(ss);
		}
	}
}







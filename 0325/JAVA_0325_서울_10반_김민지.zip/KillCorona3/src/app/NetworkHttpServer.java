package app;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class NetworkHttpServer {
	public static void main(String[] args) {
		int port = 8080;

		try (ServerSocket ss = new ServerSocket(port)) {
			System.out.println("NetworkHttpServer started");

			while (true) {
				try (Socket s = ss.accept()) { // 서버 접속
//					BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8"));
					String html = "<html><head><title>네트워크 예제</title></head><body><h1>Hello SSAFY! 와우! </h1></body></html>";

					// 패킷의 header
					bw.write("HTTP/1.1 200 OK \r\n)");
					bw.write("Content-Type: text/html;charset=utf-8\r\n");
					bw.write("Content-Length: " + html.length() + "\r\n");
					bw.write("\r\n");  // 바운더리..? 
					// 패킷의 data
					bw.write(html); // data
					bw.write("\r\n");
					bw.flush();  // 버퍼를 강제로 비운다 => 출력 내용을 바로 클라이언트에 

				} catch (IOException e) {
					e.printStackTrace();
				}

			}

		} catch (IOException e) {
			System.out.println("NetworkSimpleServer exception: " + e.getMessage());
			e.printStackTrace();
		}

		System.out.println("NetworkSimpleServer Ended");
	}

}

package app;

public class NetworkInetAddress {

}

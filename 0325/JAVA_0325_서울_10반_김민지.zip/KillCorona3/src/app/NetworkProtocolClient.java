package app;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class NetworkProtocolClient {
	public static void main(String[] args) {
		String ip = "1.231.235.240";
//		String host = "localhost";  // 127.0.0.1
		int port = 6547;
		
		try(Socket s = new Socket(ip, port)){ // 서버 접속
			BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
			
			String msg = br.readLine();
			System.out.println("서버로 부터 전송된 메세지 : " + msg);
			bw.write("교수님 그립읍니다...");
			bw.newLine();
			bw.flush();
			System.out.println(br.readLine());
			
		} catch (IOException e) {
			// 서버가 구동되어 있지 않거나 오류가 난 상황 => 서버에 접속할 수 없는 상황 
			System.out.println("NetworkSimpleClient exception: " + e.getMessage());
			e.printStackTrace();
		}
		
		System.out.println("NetworkSimpleClient Ended");
	}

}

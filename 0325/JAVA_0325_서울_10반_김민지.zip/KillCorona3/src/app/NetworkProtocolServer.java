package app;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class NetworkProtocolServer {
	public static void main(String[] args) {
		int port = 6547;

		try (ServerSocket ss = new ServerSocket(port)) {
			System.out.println("NetworkSimpleServer Started");

			while (true) { // 서버 단에서 계속 돌림
				// accept() : 클라이언트가 접속할 때까지 대기 했다가
				// 클라이언트가 접속하면 전용으로 통신할 수 있는 socket을 생성해서 리턴한다.
				try (Socket s = ss.accept()) { // 클라이언트 개인에 대한 통신 중 발생할 오류 처리
					BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
					
					// 여기서 while문으로 돌게되면 끝났을때 위로 못 올라간다. -> 싱글모듈인 상태 
					bw.write("이름을 입력하세요");
					bw.newLine();
					bw.flush();   // 버퍼를 강제로 비운다 => 출력 내용을 바로 클라이언트에게 전송 
					
					String msg = br.readLine();
					System.out.println("client : " + s.getInetAddress().toString() + " msg : " + msg);
					if(msg.equals("SSAFY")) {
						bw.write(msg + " accepted");
					}else {
						bw.write(msg + " rejected");
					}
					bw.newLine();
					bw.flush();
				}catch (Exception e) {
					System.out.println("통신 오류");
				}
			}

		} catch (IOException e) {
			System.out.println("NetworkSimpleServer exception: " + e.getMessage());
			e.printStackTrace();
		}

		System.out.println("NetworkSimpleServer Ended");
	}

}

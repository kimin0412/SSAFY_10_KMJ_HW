package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class NetworkSimpleClient {
	public static void main(String[] args) {
		String ip = "1.231.235.240";
		String host = "localhost";
		int port = 4101;
		
		try(Socket socket = new Socket(host, port)){ // 서버 접속
			System.out.println("client : " + socket.getInetAddress().toString());
			InputStream input = socket.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(input));
			
			String message = reader.readLine();
			System.out.println("서버로 부터 전송된 메세지 : " + message);
			
		} catch (IOException e) {
			// 서버가 구동되어 있지 않거나 오류가 난 상황 => 서버에 접속할 수 없는 상황 
			System.out.println("NetworkSimpleClient exception: " + e.getMessage());
			e.printStackTrace();
		}
		
		System.out.println("NetworkSimpleClient Ended");
	}

}

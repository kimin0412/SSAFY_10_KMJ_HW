package app;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class NetworkSimpleServer {
	public static void main(String[] args) {
		int port = 4101;
		
		try(ServerSocket serverSocket = new ServerSocket(port)){
			System.out.println("NetworkSimpleServer Started");
			
			while(true) {
				// accept() : 클라이언트가 접속할 때까지 대기 했다가
				//			  클라이언트가 접속하면 전용으로 통신할 수 있는 socket을 생성해서 리턴한다.
				Socket socket = serverSocket.accept();
				System.out.println("client : " + socket.getInetAddress().toString());
				OutputStream output = socket.getOutputStream();
				PrintWriter writer = new PrintWriter(output, true);
				writer.println("Hello SSAFY!");
			}
			
		} catch (IOException e) {
			System.out.println("NetworkSimpleServer exception: " + e.getMessage());
			e.printStackTrace();
		}
		
		System.out.println("NetworkSimpleServer Ended");
	}

}

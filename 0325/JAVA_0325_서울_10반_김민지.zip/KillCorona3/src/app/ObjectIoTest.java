package app;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import NetworkTest.IoUtil;
import person.Patient;

public class ObjectIoTest {
	public static void main(String[] args) {
		ObjectInputStream ois = null;
		ObjectOutputStream oos = null;
		FileInputStream fis = null;
		FileOutputStream fos = null;
		String fileName = "object.txt";
		try {
			fos = new FileOutputStream(fileName);
			oos = new ObjectOutputStream(fos);

			Patient p = new Patient("ssafy", 17, "010", "기침", "111", false);
			oos.writeObject(p);

			fis = new FileInputStream(fileName);
			ois = new ObjectInputStream(fis);
			System.out.println(ois.readObject());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			IoUtil.close(oos);
			IoUtil.close(ois);
			IoUtil.close(fos);
			IoUtil.close(fis);
		}
	}
}

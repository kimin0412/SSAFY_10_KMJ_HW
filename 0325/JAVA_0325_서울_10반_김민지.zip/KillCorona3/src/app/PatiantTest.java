package app;

import person.PatientCareAction;

class MyCare implements PatientCareAction{
	String name;
	public MyCare(String name) {
		this.name = name;
	}
	@Override
	public void whatIsYourName() {
		System.out.println(name);
	}
}


public class PatiantTest {
	public static void main(String[] args) {
		
		PatientCareAction care1 = new PatientCareAction() {
			public void whatIsYourName() {
				System.out.println("Patient.... ");
			}
		};
		
		PatientCareAction care2 = () -> {System.out.println("Patient.... ");};
		
		care2.whatIsYourName();
	}
}

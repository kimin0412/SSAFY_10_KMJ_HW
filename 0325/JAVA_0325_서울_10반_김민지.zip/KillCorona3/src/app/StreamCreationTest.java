package app;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

public class StreamCreationTest {

	public static void main(String[] args) {
		
		///////////////////////////////////
		// 1. Array로 Stream 생성하기 
		// 1.1 Arrays.stream()
		// 1.2 Stream.of()
		
		Double[] array1 = {3.1, 3.14, 5.0};
		Stream<Double> s1 = Arrays.stream(array1);
		print(s1);
		
		String[] strarray = {"ssafy","hello","hi"};
		Stream<String> s2 =  Stream.of(strarray);
		
		print(s2);
		
		////////////////////////////////////////////
		// Collection으로 Stream 생성 
		// 객체.stream()
		List<String> list = Arrays.asList("ssafy","hello","hi");
		Stream<String> s3 = list.stream();
		
		
		///////////////////////////////////////
		//3.직접생성 
		//3.1 데이타로 직접 생성
		Stream<Integer> s4 =  Stream.of(1,2,3);
		print(s4);
		
		//3.2 
		Stream<Integer> s5 = Stream.generate( () -> { return new Random().nextInt(10);}).limit(5);
		print(s5);
		
		//3.3
		Stream<Integer> s6 = Stream.iterate(1, n ->  n+2 ).limit(5);
		print(s6);
		
		
		
	}
	public static void print(Stream<?> stream) {
		stream.forEach( a -> { System.out.println(a);});
	}
}

package app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import virus.Virus;

public class StreamFilterMapTest {

	public static void main(String[] args) {
		// #1 filtering - distinct()
		{
			String[] strArray = {"A", "B", "C", "B", "D", "C"};
			Stream<String> stream = Arrays.stream(strArray);

			Stream<String> streamNew = stream.distinct();
			print(streamNew);
			// print(stream); //java.lang.IllegalStateException: stream has already been operated upon or closed
		}
		
		// #2 filtering - filter() with Predicate
		{
			Integer[] intArray = { 1, 2, 3, 4, 5 };
			Stream<Integer> stream = Arrays.stream(intArray);

			Stream<Integer> streamNew = stream.filter( (n)-> { return n > 2;});
			print(streamNew);
		}
		
		// #3 Cut - limit()
		{
			Integer[] intArray = { 1, 2, 3, 4, 5 };
			Stream<Integer> stream = Arrays.stream(intArray);

			Stream<Integer> streamNew = stream.limit(3);
			print(streamNew);
		}
		
		// #4 Cut - skip(index)  : index에 해당하는 요소를 제외하고 stream으로 리턴 
		{
			Integer[] intArray = { 1, 2, 3, 4, 5 };
			Stream<Integer> stream = Arrays.stream(intArray);

			Stream<Integer> streamNew = stream.skip(3);
			print(streamNew);
		}
		
		// #5 Sort - sorted()
		{
			Integer[] intArray = { 4, 3, 5, 1, 2 };
			Stream<Integer> stream = Arrays.stream(intArray);

			Stream<Integer> streamNew = stream.sorted();
			print(streamNew);
		}
		
		// #6 Sort - sorted(Comparator) customize it like below desc ordering
		{
			Integer[] intArray = { 4, 3, 5, 1, 2 };
			Stream<Integer> stream = Arrays.stream(intArray);    //기본이 오름차순 정렬

			                                           //내리차순   두번째인자 - 첫번째 인자 
			Stream<Integer> streamNew = stream.sorted( (n1, n2) -> { return n2 - n1;} );
			print(streamNew);
		}
		
		// #7 mapping - map() 1:1     => 요소 하나하나에 연산을 처리 
		{
			System.out.println("================================");
			Integer[] intArray = { 4, 3, 5, 1, 2 };
			Stream<Integer> stream = Arrays.stream(intArray);
			Stream<Integer> streamNew = stream.map( n -> n * 10 );
			print(streamNew);
			System.out.println(Arrays.toString(intArray));
			System.out.println("================================");
		}
		
		
		
		// #8 mapping - map() 1:1
		{
			Virus[] virusArray = { new Virus("V1", 10), new Virus("V2", 20), new Virus("V3", 30) };
			Stream<Virus> stream = Arrays.stream(virusArray);
			Stream<String> streamNew = stream.map( virus -> virus.getName() );
			print(streamNew);
		}
		
		// #9 chaining
		{
			Virus[] virusArray = { new Virus("V1", 10), new Virus("V2", 20), new Virus("V3", 30) };
			Stream<String> stream = Arrays.stream(virusArray).filter(v -> {return v.getLevel() >= 20;} ).map( virus -> virus.getName() );
			print(stream);
		}
		
		//collect    : 스트림을 List 또는 set으로 자료형을 변환 
		//             join
		//             데이타의 평균값을 리턴
		//             groupby~ 처리 
		
		Stream<String> f = Stream.of("a","b","c","d");
		
		Set<String>  f2 = f.collect(Collectors.toSet());
		System.out.println(f2);
		
	}

	public static void print(Stream<?> stream) {
		// Stream forEach with functional interface consumer
		stream.forEach( a -> System.out.print(a + " "));
		System.out.println();
	}
}

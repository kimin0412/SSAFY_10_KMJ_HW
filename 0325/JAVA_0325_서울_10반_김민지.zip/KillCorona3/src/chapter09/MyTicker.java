package chapter09;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyTicker extends Thread {
	private Frame frame;
	private Button startB, suspendB, resumeB, stopB, stateB, exitB;
	private String msg="hello world ssafy!!!!";
	private Label  msgL;
	private boolean isRun = true;
	private ActionListener handler = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			Object src = e.getSource();  //이벤트가 발생된 객체 
			if(src == startB) {
				start();
			}else if(src == suspendB) {
				suspend();
			}else if(src == resumeB) {
				resume();
			}else if(src == stopB) {
				//stop();
				isRun = false;  
			}else if(src == exitB) {
				System.exit(0);
			}
			//getState()의 상태를 추출 
			System.out.println(getState());
		}
	};
	{
		frame = new Frame("Thread 예제");
		startB 	= new Button("start");
		suspendB= new Button("suspend");
		resumeB = new Button("resume");
		stopB 	= new Button("stop");
		stateB 	= new Button("state");
		exitB 	= new Button("exit");
		
		Panel south = new Panel();
		south.add(startB);
		south.add(suspendB);
		south.add(resumeB);
		south.add(stopB);
		south.add(stateB);
		south.add(exitB);
		
		startB.addActionListener(handler);
		suspendB.addActionListener(handler);
		resumeB.addActionListener(handler);
		stopB.addActionListener(handler);
		stateB.addActionListener(handler);
		exitB.addActionListener(handler);
		
		msgL = new Label(msg, Label.CENTER);
		frame.add(msgL, "Center");
		frame.add(south,"South");
		frame.setBounds(500, 500, 350, 200);
		frame.setVisible(true);
	}
	public MyTicker() {}
	public MyTicker(ThreadGroup tg) {
		super(tg, "t1");
	}
	public void run() {
		while(isRun) {
			msg = msg.substring(1)+msg.charAt(0);
			msgL.setText(msg);
			try {
//				현재 코드를 동작시켜주는 Thread를 지정한 시간만큼 대기
//				Thread.sleep(300);
				sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		new MyTicker();
		ThreadGroup tg = Thread.currentThread().getThreadGroup();
		ThreadGroup  mtg = new ThreadGroup(tg.getParent(), "MyThreadGroup");
//		new MyTicker(mtg);
		for (ThreadGroup pg = tg
			; pg != null
			;  pg = pg.getParent()) {
			pg.list();
		}
	}
}









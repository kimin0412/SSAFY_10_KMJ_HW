package chapter09;

public class ThreadTest3 {
	public static void main(String[] args) {
		MyRunnable job = new MyRunnable();
		
//		Reference타입과 primitive타입까지 공유 
		Thread t1 = new Thread(job, "t1");
		Thread t2 = new Thread(job, "t2");
		Thread t3 = new Thread(job, "t3");
		
//		Reference타입만 공유할 수 있다 
//		Thread t1 = new Thread(new MyRunnable(), "t1");
//		Thread t2 = new Thread(new MyRunnable(), "t2");
//		Thread t3 = new Thread(new MyRunnable(), "t3");
		
		t1.start();
		t2.start();
		t3.start();
		
		System.out.println("main end.... ");
	}
}









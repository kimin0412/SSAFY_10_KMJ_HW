package chapter09.critical;

public class Producer extends Thread {
	private SyncStack stack;  //멀티 쓰레드에 의해 공유 되는 객체 
	public Producer(String name, SyncStack stack) {
		super(name);
		this.stack = stack;
	}
	public void run() {
		for (int i = 0; i < 100; i++) {
			char data = (char)('A'+ Math.random()*26);
			System.out.println(getName()+":"+data);
			stack.push(data);
		}
	}
}

package chapter09.critical;

import java.util.ArrayList;

//1. 동기화가 안되서 데이타 공유에 문제가 있고 
//   데이타가 없는 상황에서 멈춰야 하는데 계속 수행되서 문제 발생 
public class SyncStack {
	private ArrayList<Character> stack;
	public SyncStack() {
		stack = new ArrayList<Character>(150);
	}
	public void push(char data) {
		stack.add(data);
	}
	public char pop() {
		char data = ' ';
//		try {
			 data = stack.remove(stack.size()-1);
//		} catch (ArrayIndexOutOfBoundsException e) {
//			System.out.println(e);
//		}
		return data;
	}
	public synchronized String toString() {
		return stack.toString();
	}
}










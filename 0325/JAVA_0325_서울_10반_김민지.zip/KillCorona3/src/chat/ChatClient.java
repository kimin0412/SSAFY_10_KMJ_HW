package chat;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ChatClient{
	
	public static void main(String[] args) 	{
//		String ip = "localhost";
		String ip = "1.231.235.240";
//		String ip = "172.30.1.12";
		int port = 4101;
		
		
		ChatClientSwing ui = new ChatClientSwing( ip, port );
		ui.setTitle("SSAFY V1 - connected to " + ip + ":" + port);
		ui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ui.pack();
		ui.setLocationRelativeTo(null);
		ui.setResizable(false); // 크기조절 안되도록 
		ui.setVisible(true);
        
        String name = JOptionPane.showInputDialog("이름을 입력하세요.");
        ui.getChatConnect().setName(name);
	}
}

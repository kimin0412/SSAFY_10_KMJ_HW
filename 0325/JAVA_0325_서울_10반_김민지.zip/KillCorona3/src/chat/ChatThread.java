package chat;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ChatThread {
	private Socket socket;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private boolean isExit = false;

	

//	public ChatThread(Socket socket) {
//		this.socket = socket;
//		this.ois = new ObjectInputStream(socket.getInputStream());
//		this.oos = new ObjectOutputStream(socket.getOutputStream());
//	}
//	
//	public static void main() {
//		
//	}
	public void run() {
//		try {
//			while(!isExit) {
//				// 코드 작성 
//			}
//		
//		}catch (Exception e) {
//			e.printStackTrace();
//			ChatThreadList.remove()
//		}

	}

	public void sendMessage(String message) throws Exception {

	}
}

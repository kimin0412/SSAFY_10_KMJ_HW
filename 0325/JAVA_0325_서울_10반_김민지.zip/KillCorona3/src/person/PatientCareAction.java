package person;


@FunctionalInterface
public interface PatientCareAction {
	void whatIsYourName();
	default void whatIsYourCountry() {
		System.out.println("Korea!");
	}
}

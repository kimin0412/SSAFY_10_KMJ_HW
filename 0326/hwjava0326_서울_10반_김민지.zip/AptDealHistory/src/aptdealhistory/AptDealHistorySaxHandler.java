package aptdealhistory;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class AptDealHistorySaxHandler extends DefaultHandler {
	private AptDealHistory adh;
	private String temp; 
	List<AptDealHistory> list;
	
	public AptDealHistorySaxHandler() {
		list = new ArrayList<AptDealHistory>();
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		
		if(qName.equals("item")) {
			adh = new AptDealHistory();
			list.add(adh);
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		temp = new String(ch, start, length);
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if(qName.equals("거래금액")) {
			try {
				adh.setPrice(temp);
			}catch (Exception e) {
			}
		}else if(qName.equals("법정동")) {
			adh.setPlace(temp);
		}else if(qName.equals("아파트")) {
			adh.setName(temp);
		}
	}
	
	public List<AptDealHistory> getAdhs() {
		return list;
	}

	public void setAdhs(List<AptDealHistory> list) {
		this.list = list;
	}

}

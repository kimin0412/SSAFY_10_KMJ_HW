package aptdealhistory;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class AptDealHistorySaxTest {

	public static void main(String[] args) {
		
		File file = new File("./src/AptDealHistory.xml");
		SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		
		System.out.println("아파트 이름을 입력해주세요.");
		Scanner sc = new Scanner(System.in);
		String input = sc.next();
		
		try {
			SAXParser saxParser = saxParserFactory.newSAXParser();
			AptDealHistorySaxHandler handler = new AptDealHistorySaxHandler();
			saxParser.parse(file, handler);

			List<AptDealHistory> adhList = handler.getAdhs();
			
			boolean flag = false;
			for (AptDealHistory adh : adhList) {
				if(adh.getName().contains(input)) {
					System.out.println(String.format("%1$-25s%2$-10s%3$-10s", adh.getName(), adh.getPlace(),adh.getPrice() ));
					flag = true;
				}
			}
			if(flag == false)
				System.out.println("해당 이름을 가진 아파트는 없습니다.");
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
	}

}
package com.ssafy.product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * 클래스를 메모리에 로딩시키는 방법 1. 객체 생성 => JVM에서 사용하는 ClassLoader를 이용해서 클래스를 로 2. static에
 * 접근 => JVM에서 사용하는 ClassLoader를 이용해서 클래스를 로 3. Class.forName("패키지를 포함한 클래스이름");
 * => JVM에서 사용하는 ClassLoader를 이용해서 클래스를 로 4. ClassLoader를 통해 직접 로딩.
 */
public class ConnectionProxy {
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	static String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	static String id = "ssafy";
	static String password = "ssafy";

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, id, password);
	}

	public static void close(AutoCloseable c) {
		if (c != null) {
			try {
				c.close();
			} catch (Exception e) {
			}
		}
	}
}

package com.ssafy.product;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.Product;

public interface ProductDao {
	public List<Product> searchAll()	throws SQLException;
	public Product search(int gno)		throws SQLException;
	public void remove(int gno) 		throws SQLException;
	public void add(Product product)	throws SQLException;
	public void update(Product product)	throws SQLException;
	public void insert(Product product) throws SQLException;

}

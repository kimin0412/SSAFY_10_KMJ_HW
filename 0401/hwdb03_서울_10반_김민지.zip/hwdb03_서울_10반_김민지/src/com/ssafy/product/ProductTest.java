package com.ssafy.product;

import java.sql.SQLException;
import java.util.List;

public class ProductTest {
	public static void main(String[] args) {
		ProductDao dao = new ProductDaoImp();
	      List<Product> products;
	      try {
	         dao.insert(new Product(11, "태양의 마테차", 1700, "코카콜라", "sun.png","다이어트할 때 좋아요", "10"));
	         products = dao.searchAll();
	         for (Product product : products) {
	            System.out.println(product);
	         }
	         products.clear();
	         System.out.println();
	         
	         dao.update(new Product(11, "녹차", 30000, "동원", "green.png","이게 더 좋아", "10"));
	         System.out.println(dao.search(11));
	         System.out.println();
	         
	         dao.remove(11);
	         products = dao.searchAll();
	         for (Product product : products) {
	            System.out.println(product);
	         }
	         
	      } catch(SQLException e) {
	         e.printStackTrace();
	      }
	   }
}

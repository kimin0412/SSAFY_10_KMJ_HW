

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/ProductRegister.do")
public class ProductRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String desc = request.getParameter("desc");
		
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset=\"UTF-8\">");
		out.println("<title>Insert title here</title>");
		out.println("</head>");
		out.println("<body>");
		
		out.println("<h3>상품명</h3>");
		out.println("<a>" + name + "</a>");
		out.println("<br><br>");
		out.println("<h3>상품 가격</h3>");
		out.println("<a>" + price + "</a>");
		out.println("<br><br>");
		out.println("<h3>상품 설명</h3>");
		out.println("<a>" + desc + "</a>");
		out.println("<br><br>");
//		if(name != null && name.equals("ssafy")) {
//			if(password != null && password.equals("1111")) {
//				out.println("<h3>로그인 되었습니다.</h3>");
//				out.println("<a href=\"/hw/view/ProductRegister.html\">도서등록</a>");
//			}else {
//				out.println("<h3>비밀번호 오류!!!!! 다시 로그인 해주세요.</h3>");
//				out.println("<a href=\"/hw/view/ProductRegister.html\">로그인</a>");
//			}
//		}else {
//			out.println("<h3>등록되지 않은 아이디입니다.!!! 다시 로그인 해주세요.</h3>");
//			out.println("<a href=\"/hw/view/ProductRegister.html\">로그인</a>");
//		}
		out.println("</body></html>");
	}

}

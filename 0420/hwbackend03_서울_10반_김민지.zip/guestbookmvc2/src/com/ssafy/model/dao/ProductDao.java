package com.ssafy.model.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.ProductDto;

public interface ProductDao {
	public List<ProductDto> searchAll()	throws SQLException;
	public ProductDto search(int gno)		throws SQLException;
	public void remove(int gno) 		throws SQLException;
	public void add(ProductDto product)	throws SQLException;
	public void update(ProductDto product)	throws SQLException;
	public void insert(ProductDto product) throws SQLException;

}

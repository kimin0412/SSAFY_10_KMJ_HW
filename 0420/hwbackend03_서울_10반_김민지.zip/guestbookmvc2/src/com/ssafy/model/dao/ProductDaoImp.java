package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import com.ssafy.model.ProductDto;
import com.ssafy.util.DBUtil;

public class ProductDaoImp implements ProductDao {

	@Override
	public List<ProductDto> searchAll() throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from products ";
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			List<ProductDto> products = new LinkedList<>();
			while (rs.next()) {
				products.add(new ProductDto(rs.getInt("gno"), rs.getString("brand"), rs.getInt("price"),
						rs.getString("maker"), rs.getString("image"), rs.getString("info"), rs.getString("cno")));
			}
			return products;
		} finally { // try가 실행되면 반드시 실행됨
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	@Override
	public ProductDto search(int gno) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ProductDto product = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from products where gno=? ";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, gno);
			rs = stmt.executeQuery();

			if (rs.next()) {
				product = new ProductDto(rs.getInt("gno"), rs.getString("brand"), rs.getInt("price"),
						rs.getString("maker"), rs.getString("image"), rs.getString("info"), rs.getString("cno"));
			}
			return product;
		} finally { // try가 실행되면 반드시 실행됨
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	@Override
	public void remove(int gno) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = " delete from products where gno=? ";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, gno);
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	@Override
	public void add(ProductDto product) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = "insert into products(gno, brand, price, maker, image, info, cno, userid) "
					+ "values(?, ?, ?, ?, ?, ?, ?, ?) ";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, product.getGno());
			stmt.setString(2, product.getBrand());
			stmt.setInt(3, product.getPrice());
			stmt.setString(4, product.getMaker());
			stmt.setString(5, product.getImage());
			stmt.setString(6, product.getInfo());
			stmt.setString(7, product.getCno());
			stmt.setString(8, product.getUserid());
			stmt.executeUpdate();

		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	@Override
	public void update(ProductDto product) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = "update products set brand=?, price=?, maker=?, image=?, info=?, cno=? where gno=?";
			stmt = con.prepareStatement(sql);

			stmt.setString(1, product.getBrand());
			stmt.setInt(2, product.getPrice());
			stmt.setString(3, product.getMaker());
			stmt.setString(4, product.getImage());
			stmt.setString(5, product.getInfo());
			stmt.setString(6, product.getCno());
			stmt.setInt(7, product.getGno());
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	@Override
	public void insert(ProductDto product) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = "insert into products (gno, brand, price, maker, image, info, cno) values(?, ?, ?, ?, ?, ?, ?)";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, product.getGno());
			stmt.setString(2, product.getBrand());
			stmt.setInt(3, product.getPrice());
			stmt.setString(4, product.getMaker());
			stmt.setString(5, product.getImage());
			stmt.setString(6, product.getInfo());
			stmt.setString(7, product.getCno());
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}

	}

}

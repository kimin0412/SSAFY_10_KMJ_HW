package com.ssafy.model.dao;

public class ProductException extends RuntimeException {
	public ProductException() {}
	public ProductException(String msg) {
		super(msg);
	}
}

package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.ProductDto;

public interface ProductService {
	/** 번호에 해당하는 상품 정보를 추출하는 기능 */
	public ProductDto search(int gno);
	public List<ProductDto> searchAll();
	
//	/** 회원 인증을 위해 아이디와 비밀번호가 맞는지 확인하는 기능 */
//	public boolean login(String id, String pw);
	
	/** 상품을 입력할때 동일한 제품 번호가 있는지 검사하는 기능 */
	public boolean checkGno(int gno);
	
	/** 상품을 등록하는 기능 
	 * @throws SQLException */
	public void add(ProductDto product) throws SQLException;
	public void update(ProductDto product);
	public void remove(int gno);
		

}

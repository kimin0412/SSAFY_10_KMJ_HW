package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.ProductDto;
import com.ssafy.model.dao.GuestBookDaoImpl;
import com.ssafy.model.dao.ProductDao;
import com.ssafy.model.dao.ProductDaoImp;
import com.ssafy.model.dao.ProductException;

public class ProductServiceImp implements ProductService {
	private ProductDao dao = new ProductDaoImp();
	
	@Override
	public ProductDto search(int gno) {
		// TODO Auto-generated method stub
		try {
			ProductDao product = (ProductDao) dao.search(gno);
			if(product == null) throw new ProductException("등록되지 않은 상품 입니다."); 
			return dao.search(gno);
		} catch (Exception e) {
			throw new ProductException("상품 검색 중 오류 발생");
		}
	}

	@Override
	public List<ProductDto> searchAll() {
		try {
			return dao.searchAll();
		} catch (Exception e) {
			throw new ProductException("상품 정보를 조회 중 오류 발생");
		}
	}

//	@Override
//	public boolean login(String id, String pw) {
//		try {
//			Product member = dao.search(id);
//			// member 예외는 여기서 잡는다. 사용자에게 보여줄 화면에 띄워야하기 때문
//			if(member == null) throw new ProductException("등록되지 않은 아이디 입니다."); 
//			if(!member.getPassword().equals(pw))
//				throw new ProductException("비밀번호 오류!");
//			return true;
//		} catch (SQLException e) {  // SQL 만 잡아야한다.
//			throw new ProductException("인증 정보 처리 중 오류 발생");
//		}
//	}

	@Override
	public boolean checkGno(int gno) {
		// TODO Auto-generated method stub
		try {
			ProductDto product = dao.search(gno);
			if(product != null) throw new ProductException("이미 등록된 상품 입니다."); 
			return true;
		} catch (SQLException e) {
			throw new ProductException("상품 중복 체크 중 오류 발생");
		}
	}

	@Override
	public void add(ProductDto product) throws SQLException {
//		try {
//			product = dao.search(gno);
//			if(dao.ch) throw new ProductException("이미 등록된 상품 입니다."); 
//			return true;
//		} catch (SQLException e) {
//			throw new ProductException("상품 중복 체크 중 오류 발생");
//		}
		dao.add(product);
	}

	@Override
	public void update(ProductDto product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(int gno) {
		// TODO Auto-generated method stub
		
	}
}

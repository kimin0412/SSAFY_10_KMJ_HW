create database ssafyweb;

use ssafyweb;

-- DROP TABLE `guestbook`;

-- DROP TABLE `ssafy_member`;

CREATE TABLE `ssafy_member` (
	`userid`	VARCHAR(20) 	PRIMARY KEY,
	`username`	VARCHAR(20) 	NOT NULL,
	`userpwd`	VARCHAR(100) 	NOT NULL,
	`email`		VARCHAR(2000),
	`address` 	VARCHAR(2000),
	`joindate` 	TIMESTAMP		NOT NULL DEFAULT current_timestamp
);

INSERT INTO ssafy_member (userid, username, userpwd, email, address)
VALUES('admin', '관리자', 'admin', 'admin@ssafy.com','서울시 역삼동');

INSERT INTO ssafy_member (userid, username, userpwd, email, address)
VALUES('ssafy', '김싸피', 'ssafy', 'ssafy@ssafy.com','대전시 덕명동');

commit;

CREATE TABLE `guestbook` (
	`articleno`   int PRIMARY KEY auto_increment ,
	`userid`    VARCHAR(20) NULL,
	`subject`     VARCHAR(100) NULL,
	`content`     VARCHAR(2000) NULL,
	`regtime`    TIMESTAMP   NOT NULL DEFAULT current_timestamp,
	constraint `guestbook_to_member_fk` foreign key (`userid`) 
	references  `ssafy_member` (`userid`)
);
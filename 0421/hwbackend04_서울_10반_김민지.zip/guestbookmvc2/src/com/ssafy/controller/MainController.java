package com.ssafy.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.MemberDto;
import com.ssafy.model.ProductDto;
import com.ssafy.model.service.LoginService;
import com.ssafy.model.service.LoginServiceImpl;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImp;

@WebServlet("/main.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private LoginService loginService;
//	private GuestBookService guestBookService;
	private ProductService productService;

	@Override
	public void init() throws ServletException {
		super.init();
		loginService = new LoginServiceImpl();
//		guestBookService = new GuestBookServiceImpl();
		productService = new ProductServiceImp();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String root = request.getContextPath();

		String act = request.getParameter("act");
		if (act != null) {
			if ("mvlogin".equals(act)) {
				response.sendRedirect(root + "/user/login.jsp");
			} else if ("mvjoin".equals(act)) {
			} else if ("login".equals(act)) {
				login(request, response);
			} else if ("logout".equals(act)) {
				logout(request, response);
			} else if ("pradd".equals(act)) {
				response.sendRedirect(root + "/prod/add.jsp");
			} else if ("add".equals(act)) {
				addProduct(request, response);
			} else if ("lastpro".equals(act)) {
				lastProduct(request, response);
			} else if ("list".equals(act)) {
				listProduct(request, response);
			} else if ("mvmodify".equals(act)) {
			} else if ("modify".equals(act)) {
			} else if ("delete".equals(act)) {
				deleteProduct(request, response);
			} else {
			}
		}
	}

	private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "/index.jsp";
		HttpSession session = request.getSession();
		int progno = Integer.parseInt(request.getParameter("progno"));
		System.out.println(progno);
		MemberDto memberDto = (MemberDto) session.getAttribute("userinfo");

		if (memberDto != null) {

			try {
				productService.remove(progno);
				path = "/prod/removesuccess.jsp";

			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "글 삭제중 문제가 발생했습니다.");
				path = "/error/error.jsp";
			}
		} else

		{
			request.setAttribute("msg", "로그인 후 사용 가능한 페이지입니다.");
			path = "/error/error.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void modifyArticle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "/index.jsp";
	}

	private void moveModifyArticle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "/index.jsp";
	}

	private void lastProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "/index.jsp";
		try {
			path = "/prod/ResultPage.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글 목록을 조회하는 중 문제가 발생했습니다.");
			path = "/error/error.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void listProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "/index.jsp";
		String key = request.getParameter("key"); // 검색 조건
		String word = request.getParameter("word"); // 검색어
		try {
			List<ProductDto> list = productService.listProduct(key, word);
//			List<GuestBookDto> list = guestBookService.listArticle(key, word);
			request.setAttribute("products", list);
			path = "/prod/list.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "상품 목록을 조회하는 중 문제가 발생했습니다.");
			path = "/error/error.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void addProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "/index.jsp";
		HttpSession session = request.getSession();
		String userid = request.getParameter("userid");
		MemberDto memberDto = (MemberDto) session.getAttribute("userinfo");

		if (memberDto != null) {
			ProductDto productDto = new ProductDto();
			productDto.setUserid(memberDto.getUserid());
			productDto.setGno(Integer.parseInt(request.getParameter("gno")));
			productDto.setBrand(request.getParameter("name"));
			productDto.setPrice(Integer.parseInt(request.getParameter("price")));
			productDto.setInfo(request.getParameter("desc"));

			try {
//				GuestBookDto guestBookDto = null;
				productService.add(productDto);
//				GuestBookService.writeArticle(guestBookDto);
				path = "/prod/addsuccess.jsp";
				Cookie cookie1 = new Cookie("pro_userid", productDto.getUserid());
				cookie1.setPath(request.getContextPath());
				cookie1.setMaxAge(60 * 60 * 24 * 365 * 40);// 40년간 저장.
				response.addCookie(cookie1);
				
				Cookie cookie2 = new Cookie("pro_gno", Integer.toString(productDto.getGno()));
				cookie2.setPath(request.getContextPath());
				cookie2.setMaxAge(60 * 60 * 24 * 365 * 40);// 40년간 저장.
				response.addCookie(cookie2);
				
				Cookie cookie3 = new Cookie("pro_name", productDto.getBrand());
				cookie3.setPath(request.getContextPath());
				cookie3.setMaxAge(60 * 60 * 24 * 365 * 40);// 40년간 저장.
				response.addCookie(cookie3);

				Cookie cookie4 = new Cookie("pro_price", Integer.toString(productDto.getPrice()));
				cookie4.setPath(request.getContextPath());
				cookie4.setMaxAge(60 * 60 * 24 * 365 * 40);// 40년간 저장.
				response.addCookie(cookie4);

				Cookie cookie5 = new Cookie("pro_desc", productDto.getInfo());
				cookie5.setPath(request.getContextPath());
				cookie5.setMaxAge(60 * 60 * 24 * 365 * 40);// 40년간 저장.
				response.addCookie(cookie5);

				
//					

			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "글 작성중 문제가 발생했습니다.");
				path = "/error/error.jsp";
			}
		} else

		{
			request.setAttribute("msg", "로그인 후 사용 가능한 페이지입니다.");
			path = "/error/error.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		session.invalidate();
//		session.removeAttribute("userinfo");
		response.sendRedirect(request.getContextPath());
	}

	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");
		try {
			MemberDto memberDto = loginService.login(userid, userpwd);
			if (memberDto != null) {
//				session 설정
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", memberDto);

//				cookie 설정
				String idsave = request.getParameter("idsave");
				if ("saveok".equals(idsave)) {// 아이디 저장을 체크 했다면.
					Cookie cookie = new Cookie("ssafy_id", userid);
					cookie.setPath(request.getContextPath());
					cookie.setMaxAge(60 * 60 * 24 * 365 * 40);// 40년간 저장.
					response.addCookie(cookie);
				} else {// 아이디 저장을 해제 했다면.
					Cookie cookies[] = request.getCookies();
					if (cookies != null) {
						for (Cookie cookie : cookies) {
							if ("ssafy_id".equals(cookie.getName())) {
								cookie.setMaxAge(0);
								response.addCookie(cookie);
								break;
							}
						}
					}
				}
			} else {
				request.setAttribute("msg", "아이디 또는 비밀번호 확인 후 로그인해 주세요.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "로그인 중 문제가 발생했습니다.");
			path = "/error/error.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

}

package com.ssafy.model;

import java.io.Serializable;

public class ProductDto implements Serializable{
	private int gno;		// 상품 번호 
	private String brand;	// 상품 명
	private int price;		// 상품 가격
	private String maker;	// 제조사
	private String image;	// 상품 이미지
	private String info;	// 상품 정보 
	private String cno;
	private String userid;
	private String regtime;
	
	public ProductDto() {}

	public ProductDto(int gno, String brand, int price, String maker, String image, String info, String cno) {
		super();
		this.gno = gno;
		this.brand = brand;
		this.price = price;
		this.maker = maker;
		this.image = image;
		this.info = info;
		this.cno = cno;
	}

	public int getGno() {
		return gno;
	}

	public void setGno(int gno) {
		this.gno = gno;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getCno() {
		return cno;
	}

	public void setCno(String cno) {
		this.cno = cno;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getRegtime() {
		return regtime;
	}

	public void setRegtime(String regtime) {
		this.regtime = regtime;
	}

	@Override
	public String toString() {
		return "Product [gno=" + gno + ", brand=" + brand + ", price=" + price + ", maker=" + maker + ", image=" + image
				+ ", info=" + info + ", cno=" + cno + "]";
	}
	
}

package aformat.dao;

public interface AFormatDAO {

	public int idCheck(String idFromAjax) throws Exception;

}

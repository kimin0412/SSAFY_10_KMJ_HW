package aformat.service;

public interface AFormatService {

	public int idCheck(String idFromAjax) throws Exception;

}

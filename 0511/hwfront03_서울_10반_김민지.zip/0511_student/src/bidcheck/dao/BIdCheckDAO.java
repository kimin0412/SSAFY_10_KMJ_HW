package bidcheck.dao;

public interface BIdCheckDAO {

	public int idCheck(String idFromAjax) throws Exception;

}

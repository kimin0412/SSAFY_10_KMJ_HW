package bidcheck.service;

public interface BIdCheckService {

	public int idCheck(String idFromAjax) throws Exception;

}

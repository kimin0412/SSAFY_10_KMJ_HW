package cjoinmember.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import cjoinmember.dto.SsafyMember2DTO;
import cjoinmember.service.CJoinMemberService;
import cjoinmember.service.CJoinMemberServiceImpl;

@WebServlet("/CJoinMemberController")
public class CJoinMemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private CJoinMemberService service;

	@Override
	public void init() throws ServletException {
		super.init();
		service = new CJoinMemberServiceImpl();
	}

	public CJoinMemberController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		String command = request.getParameter("command");
		if(command.equals("join_member")) {
			SsafyMember2DTO dto = new SsafyMember2DTO();
			dto.setUserid(request.getParameter("mbr_id"));
			dto.setUsername(request.getParameter("mbr_nm"));
			dto.setUserpwd(request.getParameter("mbr_pwd"));
			dto.setTelephone(request.getParameter("mbr_tel"));
			dto.setEmail(request.getParameter("mbr_email"));
			dto.setAddress(request.getParameter("mbr_addr"));
			int successCnt = 0;
			try {
				successCnt = service.joinMember(dto);
			} catch (Exception e) {
				successCnt = -1;
				e.printStackTrace();
			} finally {
				PrintWriter out = response.getWriter();
				out.print(successCnt);
				out.close();
			}
		}//join_member
		else if(command.equals("login")) {
			SsafyMember2DTO dto = new SsafyMember2DTO();
			dto.setUserid(request.getParameter("mbr_id"));
			dto.setUserpwd(request.getParameter("mbr_pwd"));
			JSONArray arr = new JSONArray();
			JSONObject obj = new JSONObject();
			PrintWriter out = response.getWriter();
			try {
				dto = service.login(dto);
				if(dto.getUserid() == null || dto.getUserid().trim().equals("")) {
					obj.put("message_code", "0");
				} else {
					obj.put("message_code", "1");
					obj.put("userno", dto.getUserid());
					obj.put("userid", dto.getUserid());
					obj.put("username", dto.getUsername());
					obj.put("telephone", dto.getTelephone());
					obj.put("email", dto.getEmail());
					obj.put("address", dto.getAddress());
					HttpSession session = request.getSession();
					session.setAttribute("user_session", dto);
				}
			} catch (Exception e) {
				obj.put("message_code", "-1");
				e.printStackTrace();
			} finally {
				arr.add(obj);
				out.print(arr.toJSONString());
				out.close();
			}
		}//login
		else if(command.equals("logout")) {
			HttpSession session = request.getSession();
			session.invalidate();
			PrintWriter out = response.getWriter();
			out.print(1);
			out.close();
		}//logout
	}//process

}//class

package dselectkey.service;

import java.util.ArrayList;

public interface DSelectKeyService {

	public ArrayList<String> makeSearchList(String searchWordFromAjax) throws Exception;

}

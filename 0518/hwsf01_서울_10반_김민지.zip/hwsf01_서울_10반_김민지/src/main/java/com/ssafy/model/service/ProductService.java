package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dto.Product;


public interface ProductService {
	int insert(Product product);

	int update(Product product) throws SQLException;

	int delete(String id);

	Product select(String id) throws SQLException;

	List<Product> selectAll() throws SQLException;

}

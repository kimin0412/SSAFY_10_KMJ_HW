package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;


@Service
public class ProductServiceImpl implements ProductService {

	@Autowired	//의존하고 있는 객체를 자동 주입해주는 Annotation => byType 두개 이상 같이 있을 때 오류안남 / get,set없어도 오류안남 
	private ProductRepo productRepo;

	@Override
	public int delete(String id) {
		return productRepo.delete(id);
	}

	@Override
	public List<Product> selectAll() throws SQLException {
		return productRepo.selectAll();
	}

	@Override
	public int insert(Product product) {
		return productRepo.insert(product);
	}

	@Override
	public int update(Product product) throws SQLException {
		return productRepo.update(product);
	}

	@Override
	public Product select(String id) throws SQLException {
		return productRepo.select(id);
	}
}

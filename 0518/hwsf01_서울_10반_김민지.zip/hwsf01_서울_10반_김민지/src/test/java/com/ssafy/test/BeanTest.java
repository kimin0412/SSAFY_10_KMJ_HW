package com.ssafy.test;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:com/ssafy/config/beans.xml" })
public class BeanTest {

	@Autowired
	ProductService productService;

	@Test
	public void testProductRepo() {
		List<Product> products;
		try {
			productService.insert(new Product("1234", "태양의 마테차", 1700, "다이어트할 때 좋아요"));
			productService.insert(new Product("0111", "녹차", 30000, "이게 더 좋아"));
			productService.insert(new Product("9999", "구구구구", 2000, "비둘기둘기"));
			products = productService.selectAll();
			for (Product product : products) {
				System.out.println(product);
			}
			products.clear();
			System.out.println();

			productService.update(new Product("0111", "홍자", 3000, "더 싸짐"));
			System.out.println(productService.select("1234"));
			System.out.println();

			productService.delete("1234");
			products = productService.selectAll();
			for (Product product : products) {
				System.out.println(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

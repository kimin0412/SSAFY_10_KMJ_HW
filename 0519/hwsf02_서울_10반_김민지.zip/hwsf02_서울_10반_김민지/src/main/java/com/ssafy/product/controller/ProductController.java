package com.ssafy.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@GetMapping("listProduct.do")
	public String productList(Model model) {
		model.addAttribute("list", productService.selectAll());
		return "product/listProduct";
	}
	
	@GetMapping("insertProductForm.do")
	public String insertProductForm() {
		return "insertProduct";
	}
	
	@PostMapping("insertProduct.do")
	public String insertProduct(Product product) {
		productService.insert(product);
		
		return "redirect:listProduct.do";
	}
}

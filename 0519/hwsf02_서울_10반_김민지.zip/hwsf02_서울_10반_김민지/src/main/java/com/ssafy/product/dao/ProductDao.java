package com.ssafy.product.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.dto.Product;


public interface ProductDao {

	public List<Product> selectAll();
	
	public Product select(String id);
	
	public int insert(Product product);

	public int update(Product product);

	public int delete(String id);

}

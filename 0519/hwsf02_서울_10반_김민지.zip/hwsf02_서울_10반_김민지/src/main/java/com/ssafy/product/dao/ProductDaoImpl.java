package com.ssafy.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.ssafy.product.dto.ProductException;
import com.ssafy.product.dto.Product;
import com.ssafy.product.util.DBUtil;


//@Repository
//@Scope(value = )
@Component
public class ProductDaoImpl implements ProductDao {

	public List<Product> selectAll() {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from Product ";
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			List<Product> products = new LinkedList<Product>();
			while (rs.next()) {
				products.add(new Product(rs.getString("id"), rs.getString("name"), rs.getInt("price"),
						rs.getString("description")));
			}
			return products;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ProductException("상품 목록을 조회하는 중 오류 발생");
		} finally { // try가 실행되면 반드시 실행됨
			System.out.println("Product 전체조회성공~!!");
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	public Product select(String id) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from Product where id=? ";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, id);
			rs = stmt.executeQuery();
			if (rs.next()) {
				return new Product(rs.getString("id"), rs.getString("name"), rs.getInt("price"),
						rs.getString("description"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ProductException("상품 정보를 조회하는 중 오류 발생");
		} finally { // try가 실행되면 반드시 실행됨
			System.out.println("Product 조회성공~!!");
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return null;
	}

	public int insert(Product product) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = "insert into Product(id, name, price, description) values(?, ?, ?, ?) ";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, product.getId());
			stmt.setString(2, product.getName());
			stmt.setInt(3, product.getPrice());
			stmt.setString(4, product.getDescription());
			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProductException("상품 정보를 등록하는 중 오류 발생");

		} finally {
			System.out.println("Product 등록성공~!!");
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return 0;
	}

	public int update(Product product) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = "update Product set name=?, price=?, description=? where id=?";
			stmt = con.prepareStatement(sql);

			stmt.setString(1, product.getName());
			stmt.setInt(2, product.getPrice());
			stmt.setString(3, product.getDescription());
			stmt.setString(4, product.getId());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ProductException("상품 정보를 수정하는 중 오류 발생");
		} finally {
			System.out.println("Product 수정성공~!!");
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return 0;
	}

	public int delete(String id) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = " delete from Product where id=? ";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, id);
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new ProductException("상품 정보를 삭제하는 중 오류 발생");
		} finally {
			System.out.println("Product 삭제성공~!!");
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return 0;
	}
}

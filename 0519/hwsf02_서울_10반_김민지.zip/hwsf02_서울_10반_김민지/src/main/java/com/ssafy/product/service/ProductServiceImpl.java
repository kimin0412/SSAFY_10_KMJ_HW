package com.ssafy.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dao.ProductDao;
import com.ssafy.product.dto.Product;


@Service
public class ProductServiceImpl implements ProductService {

	@Autowired	//의존하고 있는 객체를 자동 주입해주는 Annotation => byType 두개 이상 같이 있을 때 오류안남 / get,set없어도 오류안남 
	private ProductDao productDao;

	public int delete(String id) {
		return productDao.delete(id);
	}

	public List<Product> selectAll() {
		return productDao.selectAll();
	}

	public int insert(Product product) {
		return productDao.insert(product);
	}

	public int update(Product product) {
		return productDao.update(product);
	}

	public Product select(String id) {
		return productDao.select(id);
	}
}

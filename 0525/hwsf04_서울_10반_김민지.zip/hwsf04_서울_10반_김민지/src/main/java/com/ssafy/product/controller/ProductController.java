package com.ssafy.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@RequestMapping(value = "/search", method = RequestMethod.GET) //입력폼보기	
	public String search() {
		return "product/searchResult";	
	}
	
	@RequestMapping(value = "/form", method = RequestMethod.GET) //입력폼보기	
	public String form() {
	  return "product/inputForm";	
	}
	
	@RequestMapping(value = "/form", method = RequestMethod.POST) //DB입력
	public String formInsert(Product pro) {
		productService.registry(pro);
		return "redirect:/list";	
	}
	
	
	@RequestMapping("/list")
	public String list(Model m) {		
		m.addAttribute("list",productService.findAll());//뷰와 공유할 데이터를 영역에 저장	
		return "product/list";//JSP페이지 포워딩
	}
	
	@RequestMapping(value = "/upform" , method = RequestMethod.GET)//수정폼 보이기
	public String upform(String id, Model m) {
		m.addAttribute("product",productService.find(id));
		return "product/editForm";
	}
	
	@RequestMapping(value = "/upform" , method = RequestMethod.POST)//DB수정하기
	public String update(Product pro) {
		productService.modify(pro);		
		return "redirect:/list";
	}
	
//	@RequestMapping("/delete")//DB삭제하기
//	public String delete(String id) {
//		productService.remove(id);
//		return "redirect:/list";
//	}
	
	
	
//	@GetMapping("listProduct.do")
//	public String productList(Model model) {
//		model.addAttribute("list", productService.selectAll());
//		return "product/listProduct";
//	}
//	
//	@GetMapping("insertProductForm.do")
//	public String insertProductForm() {
//		return "insertProduct";
//	}
//	
//	@PostMapping("insertProduct.do")
//	public String insertProduct(Product product) {
//		productService.insert(product);
//		
//		return "redirect:listProduct.do";
//	}
}

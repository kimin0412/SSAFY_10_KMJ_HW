package com.ssafy.product.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.product.service.ProductService;

@RestController //나 컨트롤러!! ---> servlet-context.xml등록
public class ProductController2 {
	@Autowired
	ProductService productService;
	
	
	@ExceptionHandler
	public ResponseEntity<Map<String, Object>> handler(Exception e){
		return handleFail("Product 정보 처리 중 오류 발생");
	}

	@GetMapping("/product")
	public ResponseEntity<Map<String, Object>> list(Model m) {	
		return handleSuccess(productService.findAll());//JSP페이지 포워딩
	}
	@GetMapping("/product/{id}")
	public ResponseEntity<Map<String, Object>> list(Model m, @PathVariable String id) {
		return handleSuccess(productService.find(id));//JSP페이지 포워딩
	}
	
	@PostMapping("/delete")//DB삭제하기
	public ResponseEntity<Map<String, Object>> delete(Model m, @PathVariable String id){
		return handleSuccess(productService.remove(id));
	}
	
	public ResponseEntity<Map<String, Object>> handleSuccess(Object data){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("state","ok");
		resultMap.put("data",data);
		return new ResponseEntity<Map<String,Object>>(resultMap, HttpStatus.OK);
	}
	public ResponseEntity<Map<String, Object>> handleFail(Object data){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("state","fail");
		resultMap.put("data",data);
		return new ResponseEntity<Map<String,Object>>(resultMap, HttpStatus.OK);
	}
	
	
	/*
	@RequestMapping(value = "/form", method = RequestMethod.GET) //입력폼보기	
	public String form() {
	  return "person/inputForm";	
	}
	
	@RequestMapping(value = "/form", method = RequestMethod.POST) //DB입력
	public String formInsert(Person vo) {
		service.registry(vo);
		return "redirect:/list";	
	}
	
	

	
	@RequestMapping(value = "/upform" , method = RequestMethod.GET)//수정폼 보이기
	public String upform(int no, Model m) {
		m.addAttribute("person",service.find(no));
		return "person/editForm";
	}
	
	@RequestMapping(value = "/upform" , method = RequestMethod.POST)//DB수정하기
	public String update(Person vo) {
		service.modify(vo);		
		return "redirect:/list";
	}
	
	@RequestMapping("/delete")//DB삭제하기
	public String delete(int no) {
		service.remove(no);
		return "redirect:/list";
	}
	
	*/
	
}









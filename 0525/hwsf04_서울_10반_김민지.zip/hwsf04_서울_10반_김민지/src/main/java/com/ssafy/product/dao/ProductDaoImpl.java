package com.ssafy.product.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.product.dto.Product;

@Repository
public class ProductDaoImpl implements ProductDao{

	@Autowired
	SqlSession sqlSession;
	
	
	@Override
	public int insert(Product product) {		
		return sqlSession.insert("product.insert",product);
	}

	@Override
	public List<Product> selectAll() {
		return sqlSession.selectList("product.selectAll");
	}

	@Override
	public Product select(String id) {
		return sqlSession.selectOne("product.select",id);
	}

	@Override
	public int update(Product product) {
		return sqlSession.update("product.update",product);
	}

	@Override
	public int delete(String id) {
		return sqlSession.delete("product.delete",id);
	}

}
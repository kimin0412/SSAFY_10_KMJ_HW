package com.ssafy.product.service;

import java.util.List;

import com.ssafy.product.dto.Product;

public interface ProductService {
	int registry(Product product);

	int modify(Product product);

	int remove(String id);

	Product find(String id);

	List<Product> findAll();

}

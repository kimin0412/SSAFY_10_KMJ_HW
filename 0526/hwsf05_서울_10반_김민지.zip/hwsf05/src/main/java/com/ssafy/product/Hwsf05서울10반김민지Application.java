package com.ssafy.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hwsf05서울10반김민지Application {

	public static void main(String[] args) {
		SpringApplication.run(Hwsf05서울10반김민지Application.class, args);
	}

}

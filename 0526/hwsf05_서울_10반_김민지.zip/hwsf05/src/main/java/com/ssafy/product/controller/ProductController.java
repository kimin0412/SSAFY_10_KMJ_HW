package com.ssafy.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@ExceptionHandler
	public ModelAndView handler(Exception ex) {
		ModelAndView mav = new ModelAndView("ErrorHandler");
		ex.printStackTrace();
		mav.addObject("msg", "상품 정보 처리 중 오류 발생");
		
		return mav;
	}
	
	@GetMapping("listProduct.do")
	public String productList(Model model) {
		model.addAttribute("list", productService.searchAll());
		return "product/listProduct";
	}
	
	@GetMapping("insertProductForm.do")
	public String insertProductForm() {
		return "index";
	}
	
	@PostMapping("insertProduct.do")
	public String insertProduct(Product product) {
		productService.insert(product);
		return "redirect:listProduct.do";
	}
}

package com.ssafy.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.product.dao.ProductDao;
import com.ssafy.product.dto.Product;
import com.ssafy.product.dto.ProductException;


@Service
public class ProductServiceImpl implements ProductService {

	@Autowired	//의존하고 있는 객체를 자동 주입해주는 Annotation => byType 두개 이상 같이 있을 때 오류안남 / get,set없어도 오류안남 
	private ProductDao productDao;

	@Transactional
	public void delete(String id) {
		try {
			productDao.delete(id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("상품 정보 삭제 중 오류 발생");
		}
	}

	@Transactional
	public List<Product> searchAll() {
		try {
			return productDao.searchAll();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("상품 목록 조회 중 오류 발생");
		}
	}

	@Transactional
	public void insert(Product product) {
		try {
			productDao.insert(product);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("상품 정보 저장 중 오류 발생");
		}
	}

	@Transactional
	public void update(Product product) {
		try {
			productDao.update(product);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("상품 정보 수정 중 오류 발생");
		}
	}

	@Transactional
	public Product search(String id) {
		try {
			return productDao.search(id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("상품 정보 조회 중 오류 발생");
		}
	}
}

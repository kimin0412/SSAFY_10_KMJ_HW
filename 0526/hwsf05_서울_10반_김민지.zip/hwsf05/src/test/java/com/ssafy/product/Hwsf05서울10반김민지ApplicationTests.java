package com.ssafy.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hwsf05서울10반김민지ApplicationTests {

	@Test
	void contextLoads() {
	}

}

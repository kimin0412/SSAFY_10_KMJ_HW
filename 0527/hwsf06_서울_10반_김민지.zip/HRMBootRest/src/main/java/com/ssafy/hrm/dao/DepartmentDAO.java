package com.ssafy.hrm.dao;

import java.util.List;

import com.ssafy.hrm.dto.Department;

public interface DepartmentDAO {
	
	public List<Department> findAllDepartments() throws Exception;
//	public List<String> findAllTitles() throws Exception;
	
}

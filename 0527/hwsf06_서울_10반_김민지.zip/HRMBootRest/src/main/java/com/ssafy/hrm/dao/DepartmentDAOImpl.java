package com.ssafy.hrm.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.hrm.dto.Department;


@Repository
public class DepartmentDAOImpl implements DepartmentDAO{

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<Department> findAllDepartments() throws Exception {
		return sqlSession.selectList("s_dept.findAllDepartments");
	}

//	@Override
//	public List<String> findAllTitles() throws Exception {
//		return sqlSession.selectList("s_dept.findAllTitles");
//	}
	
}

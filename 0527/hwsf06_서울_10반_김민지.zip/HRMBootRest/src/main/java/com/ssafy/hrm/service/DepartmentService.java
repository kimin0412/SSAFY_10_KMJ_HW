package com.ssafy.hrm.service;

import java.util.List;

import com.ssafy.hrm.dto.Department;


public interface DepartmentService {
	
	public List<Department> findAllDepartments() throws Exception;
//	public List<String> findAllTitles() throws Exception;
}

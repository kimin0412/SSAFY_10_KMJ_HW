package com.ssafy.hrm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.hrm.dao.DepartmentDAO;
import com.ssafy.hrm.dao.EmployeeDAO;
import com.ssafy.hrm.dto.Department;
import com.ssafy.hrm.dto.Employee;


@Service
public class DepartmentServiceImpl implements DepartmentService {
	
    @Autowired
	private DepartmentDAO departmentDao;

	@Override
	public List<Department> findAllDepartments() throws Exception {
		return departmentDao.findAllDepartments();
	}

//	@Override
//	public List<String> findAllTitles() throws Exception {
//		return departmentDao.findAllTitles();
//	}
}

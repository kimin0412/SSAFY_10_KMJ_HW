export default {
  template: `
    <div>
    <div class='text-right'>
        <input type='text' v-model.trim='name' placeholder="사원명을 검색해주세요.">
        <button  class="btn btn-primary" @click='searchName'>검색</button>
    </div>
    <div v-if="items.length">
    <table class='table  table-boardered  table-condensed'>
        <colgroup>
            <col width='20%'>
            <col width='20%'>
            <col width='20%'>
            <col width='20%'>
            <col width='20%'>
        </colgroup>  
        <tr>
            <th>사원 아이디</th>
            <th>사원명</th>
            <th>부서</th>
            <th>직책</th>
            <th>연봉</th>
        </tr>          
        <tr v-for="(emp, index) in items" :key="index + 'items'">              
            <td>{{emp.id}}</a></td>
            <td>{{emp.name}}</td>
            <td>{{emp.deptName}}</td>
            <td>{{emp.title}}</td>
            <td>{{emp.salary}}</td>
        </tr>
    </table>
</div>
<div v-else class="text-center">
    게시글이 없습니다.
</div>
<div class="text-right">
    <button class="btn btn-primary"  @click='movePage'>사원 등록</button>
</div>
    </div>
    `,
    data: function () {
        return {
          name:''
          ,items:[]
          ,src:[]
        };
      },
      
    created() {
      const emp = localStorage.getItem('emp');
      let newEmp = {
        sequence:0,
        items: [ ]
      };
      if (emp) {
          newEmp = JSON.parse(emp);
      } else {
          localStorage.setItem('emp', JSON.stringify(newEmp));
      }

      newEmp.items.sort((a,b) =>{
      return -(a.id - b.id);
      }  );

      this.items = newEmp.items;
      this.src = newEmp.items;
  },
  
  methods: {
    getFormatDate(regtime) {
    return moment(new Date(regtime)).format("YYYY.MM.DD")
    },

    movePage() {
    location.href='hrm_add.html';
    },

    searchName(){
        if(this.name!=''){
            this.items = this.src.filter(emp => emp.name==this.name)
        }else{
            this.items = this.src
        }
    }
  }
};

import Index from './components/Index.js';
import List from './components/List.js';
import Add from './components/Add.js';


Vue.use(VueRouter);
export default new VueRouter({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'index',
      component: Index,
    },
    {
      path: '/list',
      name: 'list',
      component: List,
    },
    {
      path: '/add',
      name: 'add',
      component: Add,
    },
  ],
});

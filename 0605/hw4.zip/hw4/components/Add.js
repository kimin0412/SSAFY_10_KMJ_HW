export default {
  template: `
  <div>
    <table class='table  table-boardered table-condensed '>
      <colgroup>
        <col width='50%'>
        <col width='50%'>
      </colgroup>  
      <tr>
        <th>이름</th>
        <td><input type="text" class="form-control" id="name" ref="name" v-model='name'></td>
      </tr>
      <tr>
        <th>이메일</th>
        <td><input type="text" class="form-control" id="email" ref="email" v-model='email' placeholder="중복 이메일은 불가합니다."></td>
      </tr>
      <tr>
        <th>고용일</th>
        <td><input type="text" class="form-control" id="year" ref="year" v-model='year' placeholder="YYYY-MM-DD"></td>
      </tr>
      <tr>
        <th>관리자</th>
        <td><input type="text" class="form-control" id="manager" ref="manager" v-model='manager'></td>
      </tr>
      <tr>
        <th>직책</th>
        <td>
          <select id="title" ref="title" v-model="title">
            <option disabled value="">직책을 선택해주세요.</option> 
            <option>사장</option> 
            <option>기획부장</option> 
            <option>영업부장</option>
            <option>총무부장</option>
            <option>인사부장</option>
            <option>과장</option>
            <option>영업 대표이사</option>
            <option>사원</option>
          </select>
        </td>
      </tr>
      <tr>
        <th>부서</th>
        <td><input type="text" class="form-control" id="deptName" ref="deptName" v-model='deptName'></td>
      </tr>
      <tr>
        <th>월급</th>
        <td><input type="text" class="form-control" id="salary" ref="salary" v-model='salary'></td>
      </tr>
      <tr>
        <th>커미션</th>
        <td><input type="text" class="form-control" id="commission" ref="commission" v-model='commission'  placeholder="10, 12.5, 15, 17.5, 20 중에 선택해주세요."></td>
      </tr>
    </table>
    <div class="text-right">
      <button class="btn btn-primary" @click='checkHandler'>사원 등록</button>
      <button class="btn btn-primary" @click='moveList'>사원 목록</button>
    </div>
  </div>

  `,
  data: function () {
    return {
      items:[],
      id: '',
      name: '',
      email: '',
      year: '',
      manager: '',
      deptName: '',
      title: '',
      salary: '',
      commission: ''
    };
  },
  created() {
    axios.get('http://localhost:8080/ssafy/api/employee/all')
    .then(({ data }) => {
      this.items = data;
      console.log(this.items.length);
    });
  },

  methods: {
    checkHandler() {
      let err = true;
      let msg = '';

      if(!this.name){
            msg='이름을 입력하세요.';
            this.$refs.name.focus();
          }else if(!this.email){
            msg='이메일을 입력하세요';
            this.$refs.email.focus();
          }else if(!this.year){
            msg='고용일을 입력하세요';
            this.$refs.year.focus();
          }else if(!this.manager){
            msg='관리자를 입력하세요';
            this.$refs.manager.focus();
          }else if(!this.title){
            msg='직책을 선택하세요';
          }else if(!this.deptName){
            msg='부서를 입력하세요';
            this.$refs.deptName.focus();
          }else if(!this.salary){
            msg='월급을 입력하세요';
            this.$refs.salary.focus();
          }else if(!this.commission){
            msg='커미션을 입력하세요';
            this.$refs.commission.focus();
          }else{
            err = false;
          }
          
          if(err){
            alert(msg);
          }else{
            this.createHandler()
          }
    },

    createHandler() {
      axios.get('http://localhost:8080/ssafy/api/employee/all')
      .then(({ data }) => {
        this.items = data;
        console.log(this.items.length);
      });
        var params = new URLSearchParams();
        params.append('id', this.items.length+1);
        params.append('name', this.name);
        params.append('mailid', this.email);
        params.append('start_date', this.year);
        params.append('manager_id', this.manager);
        params.append('title', this.title);
        params.append('dept_id', this.deptName);
        params.append('salary', this.salary);
        params.append('commission_pct', this.commission);

        // console.log(params);
      axios
        // .post('http://localhost:8080/ssafy/api/employee', {
        //   id: this.items.length+1,
        //   name: this.name,
        //   mailid: this.mailid,
        //   manager_id: this.manager_id,
        // })
        .post('http://localhost:8080/ssafy/api/employee', params)
        .then(({ data }) => {
          let msg = '등록 처리시 문제가 발생했습니다.';
          console.log(data);
          if (data === 'success') {
            msg = '등록이 완료되었습니다.';
          }
          alert(msg);
          this.moveList();
        })
        .catch((error) => {
          console.dir(error);
        });
    },
    moveList() {
      this.$router.push('/list');
    }
  }
};

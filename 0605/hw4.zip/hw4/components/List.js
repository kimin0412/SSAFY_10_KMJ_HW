export default {
  template: `
    <div>
    <div class='text-right'>
        <input type='text' id="name" ref="name" v-model.trim='name' placeholder="사원명을 검색해주세요.">
        <button  class="btn btn-primary" @click='searchName'>검색</button>
    </div>
    <div v-if="items.length">
    <table class='table  table-boardered  table-condensed'>
        <colgroup>
            <col width='20%'>
            <col width='20%'>
            <col width='20%'>
            <col width='20%'>
            <col width='20%'>
            <col width='20%'>
        </colgroup>  
        <tr>
            <th>사원 아이디</th>
            <th>사원명</th>
            <th>부서</th>
            <th>직책</th>
            <th>연봉</th>
            <th>이메일</th>
        </tr>          
        <tr v-for="(emp, index) in items" :key="index + 'items'">              
            <td>{{emp.id}}</a></td>
            <td>{{emp.name}}</td>
            <td>{{emp.dept_id}}</td>
            <td>{{emp.title}}</td>
            <td>{{emp.salary}}</td>
            <td>{{emp.mailid}}</td>
        </tr>
    </table>
</div>
<div v-else class="text-center">
    게시글이 없습니다.
</div>
<div class="text-right">
    <button class="btn btn-primary"  @click='movePage'>사원 등록</button>
</div>
    </div>
    `,
    data: function () {
        return {
          name:''
          ,items:[]
          ,src:[]
        };
      },
      
    created() {
        axios.get('http://localhost:8080/ssafy/api/employee/all')
        .then(({data}) => {
            this.items = data;
            this.src = this.items;
            console.log(this.items.length);
        });
    },

    methods: {
        getFormatDate(regtime) {
        return moment(new Date(regtime)).format("YYYY.MM.DD")
    },

    movePage() {
        this.$router.push('/add');
    },

    searchName(){
        if(this.name!=''){
            this.items = this.src.filter(emp => emp.name==this.name)
        }else{
            this.items = this.src
        }
    }
  }
};

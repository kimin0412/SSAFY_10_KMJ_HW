<template>
    <div>
      <p>
      <router-link to="/">HOME</router-link>&nbsp;&nbsp;
      <router-link to="/list">사원 목록</router-link>&nbsp;&nbsp;
      <router-link to="/add">사원 등록</router-link>
      </p>  
    </div>
</template>

<script>
    export default {
        name: 'NavHeader'
    }
</script>

<style lang="scss" scoped>

</style>
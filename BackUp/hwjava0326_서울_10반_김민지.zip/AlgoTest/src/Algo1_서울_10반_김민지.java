import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Algo1_서울_10반_김민지 {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int T = Integer.parseInt(br.readLine());

		top: for (int tc = 1; tc <= T; tc++) {
			int num = Integer.parseInt(br.readLine());
			if (num % 5 == 0) { // 만약 입력받은 수가 5로 나누어 떨어진다면
				System.out.println(num / 5); // 5kg짜리 봉지의 개수가 답이된다.
				continue top;

			} else { // 만약 5로 나누어 떨어지지 않는다면
				int q = num / 5; // 5짜리 봉지로 최대한 담을수 있는 값을 구한후
				for (int i = q; i > 0; i--) { // 만약 3으로 나누어 떨어지지 않는다면 뺐던 5kg에서 다시 가져와서 %3을 검사.
					int g = num - i * 5; // 5짜리 봉지로 옮긴 나머지에 대해 연산한다.
					if (g % 3 == 0) { // 나머지가 모두 3짜리 봉지로 옮길수 있다면
						System.out.println(i + (g / 3)); // 5kg봉지 개수 + (나머지 소금 무게 / 3kg)가 답이다.
						continue top;
					} 
				}
			}

			if (num % 3 == 0) { // 3으로 나누어 떨어진다면 3kg봉지로 최대한 담을수 있는값이 답이다.
				System.out.println(num / 3);
			} else { // 위의 조건에 다 맞지 않다면 3kg이나 5kg 봉지로는 옮길 수 없다.
				System.out.println(-1);
			}
		}
	}
}

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class Algo2_서울_10반_김민지 {
	static int V, E; // 정점과 간선
	static int[] check; // 방문 & 같은 집합인지 체크하는 배열변수
	static ArrayList<Integer>[] graph; // 그래프의 정보를 저장할 변수
	static boolean ans = false; // 정답을 체크하는 flag 변수

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;

		int T = Integer.parseInt(br.readLine());
		for (int tc = 1; tc <= T; tc++) {
			st = new StringTokenizer(br.readLine(), " ");
			V = Integer.parseInt(st.nextToken()); // 정점의 개수
			E = Integer.parseInt(st.nextToken()); // 간선의 개수

			graph = new ArrayList[V]; // 정점의 개수만큼 List를 선언해준다.
			ans = false; // 답의 초기값을 false로 할당해준다.
			// ans가 false라는건 아직 이분그래프 조건을 충족한다는 의미
			// 탐색하다가 조건에서 벗어나면 true로 바꾸며 탐색을 종료하기 위해서 초기값은 false로 해준다.

			for (int i = 0; i < V; i++) {
				graph[i] = new ArrayList<>(); // 정점의 개수만큼 ArrayList 초기화
			}
			check = new int[V]; // 체크 변수 초기화

			for (int i = 0; i < E; i++) {
				st = new StringTokenizer(br.readLine(), " ");
				int v1 = Integer.parseInt(st.nextToken()) - 1; // 0부터 시작하므로 정점 번호에서 -1씩 해준다.
				int v2 = Integer.parseInt(st.nextToken()) - 1; // 0부터 시작하므로 정점 번호에서 -1씩 해준다.
				graph[v1].add(v2); // 간선의 정보에 따라 각 정점에 이어지는 정점을 추가해준다.
				graph[v2].add(v1); // 간선의 정보에 따라 각 정점에 이어지는 정점을 추가해준다.
			}
			// 입력끝

			for (int i = 0; i < V; i++) {
				if (ans) // 만약 ans가 true라면 이분그래프 조건이 성립 하지 않았다는 뜻이므로 더이상 검사하지않고 탈출한다.
					break;
				if (check[i] == 0) // 만약 해당 정점을 아직 방문하지 않았다면
					bfs(i); // bfs 탐색 시작
			}

			System.out.println(ans ? "NO" : "YES"); // ans가 false라면 이분그래프 조건에 성립한다는 뜻이므로 YES를 출력한다.
		}
	}

	static void bfs(int s) {
		LinkedList<Integer> queue = new LinkedList<>(); // 큐를 선언한 후
		queue.offer(s); // 큐에 check[s]가 0인 s값을 삽입한다.
		check[s] = 1; // 방문 체크
		while (!queue.isEmpty()) { // 큐가 비어있지 않을때까지 poll하며 반복.
			int tmp = queue.poll();
			for (int v : graph[tmp]) { // 인접정점을 탐색
				if (check[v] == 0) { // 만약 인접 정점에 방문하지 않다면
					queue.add(v); // 큐에 추가해주고
					check[v] = check[tmp] * -1; // 다른 집합으로 설정한다.
				} else if (check[v] == check[tmp]) { // 방문하지 않았고 집합이 서로 같다면
					ans = true; // 이분그래프 조건에서 벗어났으므로 ans의 값을 바꾼다.
					return; // 탈출
				}
			}
		}
	}
}

package app;

public class Customer {
	private String name;
	private String address;
	private int age;

	public Customer() {
		super();
	}

	public Customer(String name, String address, int age) {
		super();
		this.name = name;
		this.address = address;
		this.age = age;
	}

	public String customerInfo() {
		return "";
	}

}

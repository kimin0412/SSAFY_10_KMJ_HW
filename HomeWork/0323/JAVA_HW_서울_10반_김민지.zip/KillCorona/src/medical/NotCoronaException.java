package medical;

import person.Patient;

/**
 * CheckedException
 * 	- 예외 처리를 하지 않으면 컴파일 에러를 발생 시킴 => 무조건 예외 처리 해야 한다.
 * 	- RuntimeException과 RuntimeException을 상속받은 sub를 제외한 나머지들...
 * 	  ex) Exception, IOException....
 * 
 * UnCheckedException
 * 	- 예외 처리를 하지 않아도 컴파일 에러가 발생하지 않는다.
 * 	  다만 예외 처리 하지 않으면 실행시에 에러가 발생할 수 있다.
 * 	  ==> 필요한 경우에만 예외 처리 한다.
 *  - RuntimeException과 RuntimeException을 상속받은 sub들
 * 
 * 									Throwable
 * 					Exception						Error (System 적인 결함)
 * 	...	  IOException		RuntimeException			- OutOfMemoryError
 * 	얘는 아무리 고쳐도 안될경우 많음	- ClassCastException	- StackOverFlowError
 * 		=> 예외처리				- NullPointException	- NoSuchMethodError
 * 								- NumberFormatException
 * 								....
 * 								=> 대부분 디버깅 대상
 * 							But, 사용자 입력처리는 예외처리 해줘야함 나머지는 개발자 문제
 * 
 * 예외 처리 방법
 * 	 - 직접 예외 처리 
 * 	 	: 오류가 발생한 곳에서 예외 처리 
 * 		try{
 * 			//오류가 발생할 곳
 * 		}catch(예외){
 * 			//예외 처리
 * 		}
 * 
 * 	 - 선언적 예외 처리
 * 		: 오류가 발생한 곳에서 예외 처리 하지 않고 메서드를 호출한 곳에서 예외 처리하도록 던진다 => 위임한다.
 * 		[modifiers] 리턴타입 메서드명([인자]) throws 예외들, ....{
 * 			//오류가 발생할 곳 => 여기서 예외 처리하지 않고 이 메서드를 호출하는 곳에서 처리해줌 
 * 		}
 * 
 * 		- 목적
 * 		1. 예외 처리의 다양성을 제공하기 위해서
 * 		   오류가 발생한 곳에서 예외 처리를 하면 메서드 호출한 프로그램에 맞게 처리가 안된다.
 * 		   메서드를 호출한 프로그램에 맞게 예외 처리 하기위해서...
 * 		   
 * 		 public static void div(int a, int b){
 * 			if(b == 0){
 * 				sysout("0으로 나눌 수 없습니다.");
 * 			}else{
 * 				sysout(a/b);
 * 			}
 * 		 }
 * 
 * 		2. 프로그램 진행 상에서 비정상적인 상황에 대한 메세지를 호출한 곳으로 전달 하고 싶을 때
 * 		  public static int div(int a, int b) {
 * 			 if(b == 0){
 * 			 	throw new RuntimeException ("0으로 나눌 수 없습니다."); -> 메서드 호출하는 곳으로 돌아감
 * 			 }else{
 * 				 return a/b;
 * 			 }
 * 		  }
 * 
 * 	 	3. 예외 처리에 대한 편리성을 제공하기 위해서
 * 		   프로그램마다 예외 처리하는 방법은 고정되어 있다. 여러 기능에서 똑같은 예외 처리 코드를 작성하지 않고 
 * 		   한곳으로 던져서 한번에 예외 처리한다.
 * 		   ex)  서버 프로그램 ==> 클라이언트의 요청을 받는 곳
 * 				GUI 프로그램 ==> 이벤트 처리하는 곳 
 * 				
 * 
 * 		
 * 
 *
 */

public class NotCoronaException extends Exception{  // RuntimeException이라면 위에서는 선언 안해줘도됨!
	/*
	 * public void addPatient(CDC cdc, Patient p) throws NotCoronaException { 이부분에서 throws ~~ 안해줘도됨 
	 */
	
	private static final long serialVersionUID = 1L; // 디폴트값 추가
	
	public NotCoronaException(String msg) {
		super(msg); // super => 상속받은 Exception
	}
	

}

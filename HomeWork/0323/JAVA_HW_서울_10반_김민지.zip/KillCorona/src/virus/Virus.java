package virus;

public class Virus {
	private String name;
	private int level;

	public Virus() {
	}

	public Virus(String name, int level) {
		this.name = name;
		this.level = level;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public boolean equals(Object o) {
		if (o != null && o instanceof Virus) {
			Virus v = (Virus) o;
			if (name != null && name.equals(v.name)) {
				return true;
			}
		}
		return false;
	}
}

package app;

public class MainCustomer extends Customer{
	private String hobby;

	public MainCustomer() {
		super();
	}

	public MainCustomer(String hobby) {
		super();
		this.hobby = hobby;
	}

	public String getHobby() {
		return hobby;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	
	/**
	 * 규칙
	 * 1. 메서드 이름과 인자가 반드시 같아야 한다.
	 * 2. 리턴타입은 
	 * 	  java6 - 리턴 타입은 무조건 같아야 한다.
	 * 	  java7 - 같거나 sub타입을 리턴한다.
	 * 		부모)  public Customer getCustomer(){}
	 * 
	 * 		자식)  public Customer getCustomer(){}
	 * 		 	  public MainCustomer getCustomer(){}
	 * 3. access modifier
	 * 	  같거나 더 넓은 범위로 override
	 * 		=> access modifier 범위를 축소하면 컴파일 에러 발생
	 * 
	 * 4. 예외 처리 
	 * 		- 부모에서 선언한 예외와 같은 예외를 던지거나 
	 * 		  sub를 던지거나
	 * 		  예외를 던지지 않아야 한다.
	 * 		  => 부모에서 선언한 예외의 super를 던지면 컴파일 에러 발생
	 * 
	 * 		  부모)  public Customer getCustomer throws RuntimeException{}
	 * 
	 * 		  자식)  public Customer getCustomer throws ClassCastException{}
	 * 		   	    public MainCustomer getCustomer(){} 
	 * 				public Customer getCustomer throws Exception{} ===> 컴파일 에러 발생
	 *   
	 */
	
	public String customerInfo() {
		return super.customerInfo();
	}
}

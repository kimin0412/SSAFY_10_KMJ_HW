package person;

public class Person {
	private String name;
	private int age;
	private String phone;
	
	public Person() {}
	public Person(String name, int age, String phone) {
		this.name = name;
		this.age = age;
		this.phone = phone;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", phone=" + phone + "]";
	}
	
	/**
	 * hashCode()는 객체가 실제는 다르지만 값이 같은 경우 같은 객체임을 표시하기 위해
	 * 				같은 코드값을 리턴하도록 구현한다. 
	 * 뭘 더하고 곱하고 이 값은 전혀 상관 없음. 데이터가 잘 분포되록 해주는것. 곱하지 않고 or, and 등등 사용해도 상관X
	 * 
	 */
	
	@Override
	public int hashCode() { // > Collection, Map 객체를 비교하기 위해 hashCode()를 호출 
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((phone == null) ? 0 : phone.hashCode());
		return result;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (age != other.age)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (phone == null) {
			if (other.phone != null)
				return false;
		} else if (!phone.equals(other.phone))
			return false;
		return true;
	}
	
	
}

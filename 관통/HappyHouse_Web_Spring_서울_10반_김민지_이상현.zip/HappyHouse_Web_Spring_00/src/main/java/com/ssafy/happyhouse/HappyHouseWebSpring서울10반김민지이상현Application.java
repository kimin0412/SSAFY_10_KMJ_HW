package com.ssafy.happyhouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyHouseWebSpring서울10반김민지이상현Application {

	public static void main(String[] args) {
		SpringApplication.run(HappyHouseWebSpring서울10반김민지이상현Application.class, args);
	}

}

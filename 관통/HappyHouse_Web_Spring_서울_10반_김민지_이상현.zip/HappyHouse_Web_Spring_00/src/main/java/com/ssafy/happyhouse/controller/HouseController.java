package com.ssafy.happyhouse.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.ssafy.happyhouse.model.dto.HouseInfoDto;
import com.ssafy.happyhouse.model.dto.HousePageBean;
import com.ssafy.happyhouse.model.service.HouseService;

@Controller
public class HouseController {
	
	@Autowired
	HouseService hService;

	@GetMapping("/houselist.do")
	public String showHouseList(HttpSession session) {
		System.out.println("!!");
		List<HouseInfoDto> list = hService.searchAllBean(new HousePageBean());
		session.setAttribute("house", list);
		session.setAttribute("data", true);
		return "house/houselist";
	}

	@GetMapping("houseinfo")
	public String showHouseInfo() {
		return "house/houseinfo";
	}

	@GetMapping("/housesearch.do")
	public String searchHouse(HttpSession session) {
		System.out.println("!!");
		List<HouseInfoDto> houses = hService.searchAllBean(new HousePageBean());
		session.setAttribute("house", houses);
		return "index_header";
	}
}

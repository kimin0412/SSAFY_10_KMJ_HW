package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.happyhouse.model.dto.HouseMemberDto;
import com.ssafy.happyhouse.model.service.HouseMemberService;

@RestController
public class HouseMemberController {

	@Autowired
	HouseMemberService service;

	@ExceptionHandler
	public ResponseEntity<Map<String, Object>> handler(Exception e) {
		return handleFail("Person 정보 처리 중 오류 발생");
	}
	
	@GetMapping(value = "/")
	public ModelAndView index() {
		return new ModelAndView("index_format");
	}
	
	@GetMapping(value = "/index_format")
	public ModelAndView index_format() {
		return new ModelAndView("index_format");
	}
	
	@GetMapping(value = "/home")
	public ModelAndView home() {
		return new ModelAndView("index");
	}
	
	@GetMapping(value = "/find_id")
	public ModelAndView find_id() {
		return new ModelAndView("user/find_id");
	}
	
	@GetMapping(value = "/find_pwd")
	public ModelAndView find_pwd() {
		return new ModelAndView("user/find_pwd");
	}
	
	@GetMapping(value = "/regist")
	public ModelAndView reg() {
		return new ModelAndView("user/join");
	}
	
	@PostMapping(value = "/login", consumes = "application/json")
	public ResponseEntity<Map<String, Object>> login(@RequestBody HouseMemberDto dto, HttpSession session) {
		if (service.check(dto) != 1) {
			return handleFail(dto);
		}
		session.setAttribute("userinfo", dto);
		return handleSuccess(dto);
	}
	
	@PostMapping(value = "/findId", consumes = "application/json")
	public ResponseEntity<Map<String, Object>> findId(@RequestBody HouseMemberDto dto) {
		HouseMemberDto find = service.searchId(dto);
		if (find == null) {
			return handleFail(find);
		}
		return handleSuccess(find);
	}
	
	@PostMapping(value = "/findPwd", consumes = "application/json")
	public ResponseEntity<Map<String, Object>> findPwd(@RequestBody HouseMemberDto dto) {
		HouseMemberDto find = service.searchPwd(dto);
		if (find == null) {
			return handleFail(find);
		}
		return handleSuccess(find);
	}
	
	@PostMapping(value = "/register", consumes = "application/json")
	public ResponseEntity<String> register(@RequestBody HouseMemberDto dto) throws Exception {
		if (service.check(dto) > 0) {
			return new ResponseEntity<String>("duplicate", HttpStatus.OK);
		}
		int res = service.add(dto);
		System.out.println(res);
		if (res == 0) {
			return new ResponseEntity<String>("fail", HttpStatus.OK);
		}
		return new ResponseEntity<String>("success", HttpStatus.OK);
	}
	
	@GetMapping(value = "/moveinfo")
	public ModelAndView moveinfo(HttpSession session) {
		HouseMemberDto dto = (HouseMemberDto) session.getAttribute("userinfo");
		HouseMemberDto find = service.search(dto.getUserid());
		session.setAttribute("userinfo", find);
		return new ModelAndView("user/info");
	}
	
	@GetMapping(value = "/mvmodify")
	public ModelAndView mvmodify(HttpSession session) {
		HouseMemberDto dto = (HouseMemberDto) session.getAttribute("userinfo");
		HouseMemberDto find = service.search(dto.getUserid());
		session.setAttribute("userinfo", find);
		return new ModelAndView("user/modify");
	}
	
	@PostMapping(value = "/modify", consumes = "application/json")
	public ResponseEntity<String> modify(@RequestBody HouseMemberDto dto) throws Exception {
		System.out.println(dto);
		int res = service.update(dto);
		System.out.println(res);
		if (res == 0) {
			return new ResponseEntity<String>("fail", HttpStatus.OK);
		}
		return new ResponseEntity<String>("success", HttpStatus.OK);
	}

	@GetMapping("/logout")
	public ResponseEntity<String> logout(Model m, HttpSession session) {	
		HouseMemberDto dto = (HouseMemberDto) session.getAttribute("userinfo");
		int check = service.check(dto);
		if(check == 0) {
			return new ResponseEntity<String>("fail", HttpStatus.OK);
		}
		session.invalidate();
		return new ResponseEntity<String>("success", HttpStatus.OK);
	}
	
	@GetMapping("/signout")
	public ResponseEntity<String> signout(Model m, HttpSession session) {	
		HouseMemberDto dto = (HouseMemberDto) session.getAttribute("userinfo");
		int check = service.check(dto);
		if(check == 0) {
			return new ResponseEntity<String>("fail", HttpStatus.OK);
		}
		service.remove(dto.getUserid());
		session.invalidate();
		return new ResponseEntity<String>("success", HttpStatus.OK);
	}
	
	public ResponseEntity<Map<String, Object>> handleSuccess(Object data){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("state","success");
		resultMap.put("data",data);
		return new ResponseEntity<Map<String,Object>>(resultMap, HttpStatus.OK);
	}
	
	public ResponseEntity<Map<String, Object>> handleFail(Object data){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("state","fail");
		resultMap.put("data",data);
		return new ResponseEntity<Map<String,Object>>(resultMap, HttpStatus.OK);
	}
	
}

//package com.ssafy.happyhouse.controller;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.Collections;
//import java.util.Comparator;
//import java.util.List;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//
//import com.ssafy.happyhouse.model.dao.HouseMemberDao;
//import com.ssafy.happyhouse.model.dao.HouseMemberDaoImpl;
//import com.ssafy.happyhouse.model.dto.HouseDealDto;
//import com.ssafy.happyhouse.model.dto.HouseMemberDto;
//import com.ssafy.happyhouse.model.dto.HousePageBean;
//import com.ssafy.happyhouse.model.dto.ShopInfoDto;
//import com.ssafy.happyhouse.model.service.HouseMemberService;
//import com.ssafy.happyhouse.model.service.HouseMemberServiceImpl;
//import com.ssafy.happyhouse.model.service.HouseService;
//import com.ssafy.happyhouse.model.service.HouseServiceImpl;
//import com.ssafy.happyhouse.model.service.LoginService;
//import com.ssafy.happyhouse.model.service.LoginServiceImpl;
//import com.ssafy.happyhouse.model.service.ShopInfoService;
//import com.ssafy.happyhouse.model.service.ShopInfoServiceImpl;
//import com.ssafy.util.PageNavigation;
//
//@WebServlet("/main.do")
//public class MainController extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//
//	private LoginService loginService;
//	private HouseMemberService memberService;
//	private ShopInfoService shopInfoService;
//	private HouseService houseService;
//
//	@Override
//	public void init() throws ServletException {
//		super.init();
//		loginService = new LoginServiceImpl();
//		memberService = new HouseMemberServiceImpl();
//		shopInfoService = new ShopInfoServiceImpl();
//		houseService = new HouseServiceImpl();
//	}
//
//	protected void doGet(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		try {
//			process(request, response);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	protected void doPost(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		request.setCharacterEncoding("utf-8");
//		try {
//			process(request, response);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	private void process(HttpServletRequest request, HttpServletResponse response)
//			throws Exception {
//		String root = request.getContextPath();
//
//		String act = request.getParameter("act");
//		if (act != null) {
//			if ("mvlogin".equals(act)) { // 로그인화면 이동
//				response.sendRedirect(root + "/user/login.jsp");
//			} else if ("login".equals(act)) { // 로그인 기능
//				login(request, response);
//			} else if ("join".equals(act)) { // 회원가입 기능
//				join(request, response);
//			} else if ("logout".equals(act)) { // 로그아웃 기능
//				logout(request, response);
//			} else if ("signout".equals(act)) { // 회원탈퇴 기능
//				signout(request, response);
//			} else if ("mvinfo".equals(act)) { // 회원정보 기능
//				moveInfo(request, response);
//			} else if ("shopinfolist".equals(act)) { // 상권정보리스트 보기
//				listShop(request, response);
//			} else if ("mvshopinfomodify".equals(act)) { // 상권정보수정화면 이동
//				response.sendRedirect(root + "/prod/shopinfomodify.jsp");
//			} else if ("houselist".equals(act)) { // 집정보리스트 보기
//				listHouse(request, response);
//			} else if ("".equals(act)) {
////				lastProduct(request, response);
//			} else if ("mvmodify".equals(act)) {
//				response.sendRedirect(root + "/user/modify.jsp");
//			} else if ("modify".equals(act)) {
//				modify(request, response);
//			} else if ("delete".equals(act)) {
////				deleteProduct(request, response);
//			} else if ("mvmain".equals(act)) {
//				mvmain(request, response);
//			} else if ("find_id".equals(act)) {
//				find_id(request, response);
//			} else if ("find_pwd".equals(act)) {
//				find_pwd(request, response);
//			} else {
//
//			}
//		}
//		/*
//		 * mvshopinfomodify&shopinfono=${shopInfoDto.no}">수정</a>
//		 * shopinfodelete&shopinfono=${shopInfoDto.no}">삭제</a>
//		 */
//
//	}
//
//	private void find_pwd(HttpServletRequest request, HttpServletResponse response) throws Exception {
//		HouseMemberDto memberDto = new HouseMemberDto();
//		memberDto.setId(request.getParameter("mbr_id"));
//		memberDto.setEmail(request.getParameter("mbr_email"));
//		JSONArray arr = new JSONArray();
//		JSONObject obj = new JSONObject();
//		PrintWriter out = response.getWriter();
//		try {
//			memberDto = memberService.searchPwd(memberDto.getId(), memberDto.getEmail());
//			obj.put("message_code", "1");
//			obj.put("userpwd", memberDto.getPassword());
//			System.out.println("!!!" + memberDto.getPassword());
//			HttpSession session = request.getSession();
//			session.setAttribute("user_session", memberDto);
//		} catch (Exception e) {
//			obj = new JSONObject();
//			obj.put("message_code", "-1");
//			e.printStackTrace();
//		} finally {
//			arr.add(obj);
//			out.print(arr.toJSONString());
//			out.close();
//		}
//	}
//
//	private void find_id(HttpServletRequest request, HttpServletResponse response) throws Exception {
//		HouseMemberDto memberDto = new HouseMemberDto();
//		memberDto.setName(request.getParameter("mbr_nm"));
//		memberDto.setPhone(request.getParameter("mbr_tel"));
//		String id = "";
//		JSONArray arr = new JSONArray();
//		JSONObject obj = new JSONObject();
//		PrintWriter out = response.getWriter();
//		try {
//			memberDto = memberService.searchId(memberDto.getName(), memberDto.getPhone());
//			obj.put("message_code", "1");
//			obj.put("userid", memberDto.getId());
//			System.out.println("!!!" + memberDto.getId());
//			HttpSession session = request.getSession();
//			session.setAttribute("user_session", memberDto);
//		} catch (Exception e) {
//			obj = new JSONObject();
//			obj.put("message_code", "-1");
//			e.printStackTrace();
//		} finally {
//			arr.add(obj);
//			out.print(arr.toJSONString());
//			out.close();
//		}
//	}
//
//	private void modify(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		HouseMemberDto memberDto = new HouseMemberDto();
//		memberDto.setId(request.getParameter("id"));
//		memberDto.setName(request.getParameter("name"));
//		memberDto.setPassword(request.getParameter("userpwd"));
//		memberDto.setPhone(request.getParameter("tel"));
//		memberDto.setEmail(request.getParameter("email"));
//		memberDto.setAddress(request.getParameter("address"));
//		System.out.println(memberDto);
//		int successCnt = 0;
//		try {
//			successCnt = memberService.update(memberDto);
//			System.out.println(successCnt);
//		} catch (Exception e) {
//			successCnt = -1;
//			e.printStackTrace();
//		} finally {
//			PrintWriter out = response.getWriter();
//			out.print(successCnt);
//			out.close();
//		}
//	}
//
//	private void mvmain(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		String path = "/index.jsp";
//		try {
//			HttpSession session = request.getSession();
//			HouseMemberDto memberDto = (HouseMemberDto) session.getAttribute("userinfo");
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			request.setAttribute("msg", "이동 중 문제가 발생했습니다.");
//			path = "/error/error.jsp";
//		}
//		request.getRequestDispatcher(path).forward(request, response);
//	}
//
//	private void join(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		HouseMemberDto memberDto = new HouseMemberDto();
//		memberDto.setId(request.getParameter("mbr_id"));
//		memberDto.setName(request.getParameter("mbr_nm"));
//		memberDto.setPassword(request.getParameter("mbr_pwd"));
//		memberDto.setPhone(request.getParameter("mbr_tel"));
//		memberDto.setEmail(request.getParameter("mbr_email"));
//		memberDto.setAddress(request.getParameter("mbr_addr"));
//		int successCnt = 0;
//		try {
//			successCnt = memberService.add(memberDto);
//		} catch (Exception e) {
//			successCnt = -1;
//			e.printStackTrace();
//		} finally {
//			PrintWriter out = response.getWriter();
//			out.print(successCnt);
//			out.close();
//		}
//	}
//
//	private void signout(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		String path = "/index.jsp";
//		HttpSession session = request.getSession();
//		HouseMemberDto dao = (HouseMemberDto) session.getAttribute("userinfo");
//
//		try {
//			HouseMemberDao memberDao = new HouseMemberDaoImpl();
//			memberDao.remove(dao.getId());
//			session.invalidate();
//			path = "/index.jsp";
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			request.setAttribute("msg", "조회 중 문제가 발생했습니다.");
//			path = "/error/error.jsp";
//		}
//		request.getRequestDispatcher(path).forward(request, response);
//	}
//
////	private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
////			throws ServletException, IOException {
////		String path = "/index.jsp";
////		HttpSession session = request.getSession();
////		int progno = Integer.parseInt(request.getParameter("progno"));
////		System.out.println(progno);
////		HouseMemberDto memberDto = (HouseMemberDto) session.getAttribute("userinfo");
////
////		if (memberDto != null) {
////
////			try {
////				productService.remove(progno);
////				path = "/prod/removesuccess.jsp";
////
////			} catch (Exception e) {
////				e.printStackTrace();
////				request.setAttribute("msg", "글 삭제중 문제가 발생했습니다.");
////				path = "/error/error.jsp";
////			}
////		} else
////
////		{
////			request.setAttribute("msg", "로그인 후 사용 가능한 페이지입니다.");
////			path = "/error/error.jsp";
////		}
////		request.getRequestDispatcher(path).forward(request, response);
////	}
////
////	private void modifyArticle(HttpServletRequest request, HttpServletResponse response)
////			throws ServletException, IOException {
////		String path = "/index.jsp";
////	}
////
////	private void moveModifyArticle(HttpServletRequest request, HttpServletResponse response)
////			throws ServletException, IOException {
////		String path = "/index.jsp";
////	}
////
////	private void lastProduct(HttpServletRequest request, HttpServletResponse response)
////			throws ServletException, IOException {
////		String path = "/index.jsp";
////		try {
////			path = "/prod/ResultPage.jsp";
////		} catch (Exception e) {
////			e.printStackTrace();
////			request.setAttribute("msg", "글 목록을 조회하는 중 문제가 발생했습니다.");
////			path = "/error/error.jsp";
////		}
////		request.getRequestDispatcher(path).forward(request, response);
////	}
////
//	private void listHouse(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		String path = "/index.jsp";
//		// 검색 조건
//		/**
//		 * 0 : 아파트 매매 1 : 아파트 전월세 2 : 다세대 매매 3 : 다세대 전월세
//		 */
//		boolean[] searchType = { false, false, false, false };
//		String[] stype = request.getParameterValues("searchtype");
//		if (stype == null) {
//			searchType = new boolean[] { true, true, true, true };
//		} else {
//			for (String type : stype) {
//				searchType[Integer.parseInt(type)] = true;
//			}
//		}
//
//		int currentPage = Integer.parseInt(request.getParameter("pg"));
//		String spp = request.getParameter("spp");
//		int sizePerPage = spp == null ? 10 : Integer.parseInt(spp);// sizePerPage
//
//		String key = request.getParameter("key"); // 검색종류
//		String word = request.getParameter("word"); // 검색어
//		System.out.println("key" + key);
//		System.out.println("word" + word);
////		if(order == "")
////			order = "year";
////		
//		HousePageBean bean = new HousePageBean();
//		bean.setSearchType(searchType);
//		if (key.equals("dong")) {
//			bean.setDong(word);
//		} else if (key.equals("aptName")) {
//			bean.setAptname(word);
//		}
//
//		try {
//			List<HouseDealDto> list = houseService.searchAll(currentPage, sizePerPage, bean);
//
////			System.out.print("정렬전 : ");
////			for (int i = 0; i < list.size(); i++) {
////				System.out.println(list.get(i).getBuildYear());
////			}
//
//			Collections.sort(list, new Comparator<HouseDealDto>() {
//
//				@Override
//				public int compare(HouseDealDto hd1, HouseDealDto hd2) {
//					String order = request.getParameter("order"); // 정렬 종류
//					if (order == null)
//						order = "year";
//
////					System.out.println("key : " + key);
////					System.out.println(order);
//					// TODO Auto-generated method stub
//					if (order.equals("year")) {
//						if (hd1.getBuildYear() < hd2.getBuildYear())
//							return 1;
//						else if (hd1.getBuildYear() > hd2.getBuildYear())
//							return -1;
//						else
//							return 0;
//					}
//					if (order.equals("price")) {
//						int a = Integer.parseInt(hd1.getDealAmount().trim().replace(",", ""));
//						int b = Integer.parseInt(hd2.getDealAmount().trim().replace(",", ""));
//						if (a < b)
//							return 1;
//						else if (a > b)
//							return -1;
//						else
//							return 0;
//					}
//					if (order.equals("area")) {
//						if (hd1.getArea() < hd2.getArea())
//							return 1;
//						else if (hd1.getArea() > hd2.getArea())
//							return -1;
//						else
//							return 0;
//					}
//
//					return 0;
//				}
//			});
////			System.out.print("정렬후 : ");
////			for (int i = 0; i < list.size(); i++) {
////				System.out.println(list.get(i).getBuildYear());
////			}
//			request.setAttribute("houseInfos", list);
//
//			PageNavigation pageNavigation = houseService.makePageNavigation(currentPage, sizePerPage, key, word);
//			request.setAttribute("navigation", pageNavigation);
//
//			System.out.println("집 갯수 :" + list.size());
//			path = "/prod/houselist.jsp";
//		} catch (
//
//		Exception e) {
//			e.printStackTrace();
//			request.setAttribute("msg", "집 목록을 조회하는 중 문제가 발생했습니다.");
//			path = "/error/error.jsp";
//		}
//		request.getRequestDispatcher(path).forward(request, response);
//	}
//
//	private void listShop(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		String path = "/index.jsp";
//
//		int currentPage = Integer.parseInt(request.getParameter("pg"));
//		String spp = request.getParameter("spp");
//		int sizePerPage = spp == null ? 8 : Integer.parseInt(spp);// sizePerPage
//
//		String key = request.getParameter("key"); // 검색 조건
//		String word = request.getParameter("word"); // 검색어
//		try {
//			List<ShopInfoDto> list = shopInfoService.searchAll(currentPage, sizePerPage, key, word);
//			PageNavigation pageNavigation = shopInfoService.makePageNavigation(currentPage, sizePerPage, key, word);
//			request.setAttribute("shopInfos", list);
//			request.setAttribute("navigation", pageNavigation);
//			System.out.println("상권 갯수 :" + list.size());
//			path = "/prod/shopinfolist.jsp";
//		} catch (Exception e) {
//			e.printStackTrace();
//			request.setAttribute("msg", "상권 목록을 조회하는 중 문제가 발생했습니다.");
//			path = "/error/error.jsp";
//		}
//		request.getRequestDispatcher(path).forward(request, response);
//	}
//
//	private void lastProduct(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		String path = "/index.jsp";
//		try {
//			path = "/prod/ResultPage.jsp";
//		} catch (Exception e) {
//			e.printStackTrace();
//			request.setAttribute("msg", "글 목록을 조회하는 중 문제가 발생했습니다.");
//			path = "/error/error.jsp";
//		}
//		request.getRequestDispatcher(path).forward(request, response);
//	}
//
//	private void moveInfo(HttpServletRequest request, HttpServletResponse response)
//			throws IOException, ServletException {
//		System.out.println("!!!");
//		HttpSession session = request.getSession();
//		HouseMemberDto dao = (HouseMemberDto) session.getAttribute("userinfo");
//
//		String path = "/index.jsp";
//		try {
//			HouseMemberDao memberDao = new HouseMemberDaoImpl();
//			HouseMemberDto info = memberDao.search(dao.getId());
//			System.out.println(info);
//
//			request.setAttribute("info", info);
//			path = "/user/info.jsp";
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			request.setAttribute("msg", "조회 중 문제가 발생했습니다.");
//			path = "/error/error.jsp";
//		}
//		request.getRequestDispatcher(path).forward(request, response);
//	}
//
//	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
//		HttpSession session = request.getSession();
//		session.invalidate();
//		PrintWriter out = response.getWriter();
//		out.print(1);
//		out.close();
//	}
//
//	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		String path = "/index.jsp";
//		HouseMemberDto memberDto = new HouseMemberDto();
//		String userid = request.getParameter("mbr_id");
//		String userpwd = request.getParameter("mbr_pwd");
//		JSONArray arr = new JSONArray();
//		JSONObject obj = new JSONObject();
//		PrintWriter out = response.getWriter();
//		try {
//			memberDto = loginService.login(userid, userpwd);
//			if (memberDto.getId() == null || memberDto.getId().trim().equals("")) {
//				obj.put("message_code", "0");
//			} else {
//				obj.put("message_code", "1");
//				obj.put("userno", memberDto.getId());
//				obj.put("userid", memberDto.getId());
//				obj.put("username", memberDto.getName());
//				obj.put("telephone", memberDto.getPhone());
//				obj.put("email", memberDto.getEmail());
//				obj.put("address", memberDto.getAddress());
//				HttpSession session = request.getSession();
//				session.setAttribute("userinfo", memberDto);
//
//			}
//		} catch (Exception e) {
//			obj.put("message_code", "-1");
//			e.printStackTrace();
//		} finally {
//			arr.add(obj);
//			out.print(arr.toJSONString());
//			out.close();
//		}
//	}
//}

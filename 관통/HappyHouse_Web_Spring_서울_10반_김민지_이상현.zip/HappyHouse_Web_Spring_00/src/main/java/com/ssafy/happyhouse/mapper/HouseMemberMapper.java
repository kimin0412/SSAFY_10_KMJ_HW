package com.ssafy.happyhouse.mapper;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.dto.HouseMemberDto;

@Mapper
public interface HouseMemberMapper {

//	public int register(HouseMemberDto dto);

	/** 회원 인증을 위해 id와 비밀번호가 맞는지 확인하는 기능*/
//	public int check(String id);
	public int check(HouseMemberDto dto);
	
	/** 회원 가입 시 동일한id가 있는지 검사하는 기능*/
	public int checkId(HouseMemberDto dto);
	public HouseMemberDto detail(String id);

	/** id에 해당하는 회원 정보를 추출하는 기능*/
	public HouseMemberDto search(String id);
	public HouseMemberDto searchId(HouseMemberDto dto);
	public HouseMemberDto searchPwd(HouseMemberDto dto);
	public List<HouseMemberDto> searchAll();
	
	// 회원 등록하는 기능
	public int add(HouseMemberDto housememberDto) throws Exception;
	public int update(HouseMemberDto housememberDto) throws Exception;
	public void remove(String id);
	
	
//	public int insert(PatientDto dto);
//	public int check(String pno);
//	public List<PatientDto> select();
//	public PatientDto detail(String pno);
}

package com.ssafy.happyhouse.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.model.dto.HouseDealDto;
import com.ssafy.happyhouse.model.dto.HouseInfoDto;
import com.ssafy.happyhouse.model.dto.HousePageBean;
import com.ssafy.happyhouse.utll.DBUtil;


public class HouseDaoImpl implements HouseDao{
	private Map<String, HouseInfoDto> houseInfo;
	private Map<String, List<HouseDealDto>> deals;
	private int size;
	private List<HouseDealDto>search;
	private String[] searchType= {HouseDealDto.APT_DEAL, HouseDealDto.APT_RENT, HouseDealDto.HOUSE_DEAL, HouseDealDto.HOUSE_RENT};
	private String[] ImgName = {
			"건양하늘터.jpg"
			, "경희궁의아침.jpg"
			, "광화문풍림스페이스본.jpg"
			, "교북동경희궁자이(4단지).jpg"
			, "다세대주택.jpg"
			, "동성아파트.jpg"
			, "무악동인왕산아이파크.jpg"
			, "무악동현대.jpg"
			, "숭인동롯데캐슬천지인.jpg"
			, "숭인동삼전솔하임2차.jfif"
			, "숭인동숭인한양LEEPS.jfif"
			, "숭인동종로센트레빌.jfif"
			, "숭인동종로중흥S클래스.jfif"
			, "숭인동종로청계힐스테이트.jfif"
			, "신동아블루아광화문.jpg"
			, "아남1.jpg"
			, "창신동덕산.jpg"
			, "창신동두산.jpg"
			, "창신동창신쌍용1.jpg"
			, "창신동창신쌍용2.jpg"
			, "평동경희궁자이(3단지).jpg"
			, "평창동갑을.jpg"
			, "평창동삼성.jfif"
			, "평창동엘리시아.jfif"
			, "현대뜨레비앙.jpg"
			, "홍파동경희궁자이(2단지).jpg"
			, "효성쥬얼리시티.jfif"
			, "CS타워.jfif"
	};
	
	
	public HouseDaoImpl() {
	}
	/**
	 * 아파트 정보와 아파트 거래 정보를  xml 파일에서 읽어온다.
	 */
	public void loadData() { }
	
	/**
	 * 검색 조건(key) 검색 단어(word)에 해당하는 아파트 거래 정보(HouseInfo)를  검색해서 반환.  
	 * @param bean  검색 조건과 검색 단어가 있는 객체
	 * @return 조회한 식품 목록
	 */
	public List<HouseDealDto> searchAll(int currentPage, int sizePerPage, HousePageBean bean) throws SQLException{
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder(100);
			sql.append(" select * from housedeal where 1 = 1 ");
			sql.append(" and type in ( ");
			boolean[] type = bean.getSearchType();
			for(int i = 0 , size = type.length; i < size; i++) {
				if (type[i]) {
					sql.append(i+1 +",");
				}
			}
            sql.replace(sql.length()-1, sql.length(), "");
			sql.append(" ) ");
			String dong = bean.getDong();
			String aptName = bean.getAptname();
			
			System.out.println("dong:"+dong);
			System.out.println("aptName:"+aptName);
			if (dong != null && !dong.trim().equals("")) {
				sql.append(" and dong like ? ");
			} else if (aptName != null && !aptName.trim().equals("")) {
				sql.append(" and aptname like ? ");
			}
			
			sql.append(" limit ?, ? ");
			int idx = 0;
			stmt = con.prepareStatement(sql.toString());
			if (dong != null && !dong.trim().equals("")) {
				stmt.setString(++idx, "%"+dong+"%");
			} else if (aptName != null && !aptName.trim().equals("")) {
				stmt.setString(++idx, "%" + aptName+ "%");
			}
			stmt.setInt(++idx,(currentPage - 1) * sizePerPage);
			stmt.setInt(++idx,sizePerPage);
			System.out.println(">>>>>>>>>SEARCH ALL>>>>>>>>");
			System.out.println(stmt.toString());
			rs = stmt.executeQuery();
			
			List<HouseDealDto> list = new LinkedList<HouseDealDto>();
			while (rs.next()) {
				HouseDealDto deal = new HouseDealDto();
				deal.setNo(rs.getInt("no"));
				deal.setDong(rs.getString("dong"));
				deal.setAptName(rs.getString("aptName"));
				deal.setCode(rs.getInt("code"));
				deal.setDealAmount(rs.getString("dealAmount"));
				deal.setBuildYear(rs.getInt("buildYear"));
				deal.setDealYear(rs.getInt("dealYear"));
				deal.setDealMonth(rs.getInt("dealMonth"));
				deal.setDealDay(rs.getInt("dealDay"));
				deal.setArea(rs.getDouble("area"));
				deal.setFloor(rs.getInt("floor"));
				deal.setJibun(rs.getString("jibun"));
				deal.setType(rs.getString("type"));
				deal.setRentMoney(rs.getString("rentMoney"));
				
				deal.setImg("img/"+"다세대주택.jpg");	//default
				for (String imgName : ImgName) {
					String[] filesplit =imgName.split("\\.");   //{이름, 확장자}로 나눔
					if(deal.getAptName().contains(filesplit[0])) {
						deal.setImg("img/"+imgName);
						System.out.println(imgName);
						break;
					}
		        }
				list.add(deal);
			}
			return list;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}
	
	/**
	 * 아파트 식별 번호에 해당하는 아파트 거래 정보를 검색해서 반환한다.<br/>
	 * 법정동+아파트명을 이용하여 HouseInfo에서 건축연도, 법정코드, 지번, 이미지 정보를 찾아서 HouseDeal에 setting한 정보를 반환한다. 
	 * @param no	검색할 아파트 식별 번호
	 * @return		아파트 식별 번호에 해당하는 아파트 거래 정보를 찾아서 리턴한다, 없으면 null이 리턴됨
	 */
	public HouseDealDto search(int no) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from housedeal where no = ? ";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, no);
			
			rs = stmt.executeQuery();
			if (rs.next()) {
				HouseDealDto deal = new HouseDealDto();
				deal.setNo(rs.getInt("no"));
				deal.setDong(rs.getString("dong"));
				deal.setAptName(rs.getString("aptName"));
				deal.setCode(rs.getInt("code"));
				deal.setDealAmount(rs.getString("dealAmount"));
				deal.setBuildYear(rs.getInt("buildYear"));
				deal.setDealYear(rs.getInt("dealYear"));
				deal.setDealMonth(rs.getInt("dealMonth"));
				deal.setDealDay(rs.getInt("dealDay"));
				deal.setArea(rs.getDouble("area"));
				deal.setFloor(rs.getInt("floor"));
				deal.setJibun(rs.getString("jibun"));
				deal.setType(rs.getString("type"));
				deal.setRentMoney(rs.getString("rentMoney"));
				
//				File[] fileList = new File("img").listFiles();   //img내부의 파일 읽기ㅇ
//				for (File file : fileList) {
//					if(file.isFile()) {
//						String fileName = file.getName();
//						String[] filesplit =fileName.split("\\.");   //{이름, 확장자}로 나눔
//						if(deal.getAptName().contains(filesplit[0])) {
//							deal.setImg("../img/"+fileName);
//							System.out.println(fileName);
//							break;
//		               }
//		            }
//		         }
				return deal;
			}
			return null;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}
	
	@Override
	public int getTotalCount(String key, String word) throws SQLException {
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select count(no) \n");
			sql.append("from housedeal \n");
			if(!word.isEmpty()) {
				if("aptName".equals(key)) {
					sql.append("where aptName like ? \n");
				} else {
					sql.append("where " + key + " like ? \n");
				}
			}
			sql.append("order by no desc \n");
			System.out.println(sql);
			pstmt = conn.prepareStatement(sql.toString());
			if(!word.isEmpty()) {
				if("aptName".equals(key))
					pstmt.setString(1, "%" + word + "%");
				else
					pstmt.setString(1, "%" + word + "%");
			}
			System.out.println(pstmt.toString());
			rs = pstmt.executeQuery();
			rs.next();
			cnt = rs.getInt(1);
			System.out.println(cnt+"검색된 갯수");
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return cnt;
	}
	
	public static void main(String[] args) {
		HouseDao dao = new HouseDaoImpl();
		
		try {
			HouseDealDto deal = dao.search(1);
			System.out.println(deal);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}






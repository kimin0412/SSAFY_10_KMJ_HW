package com.ssafy.happyhouse.model.dao;

public class HouseException extends RuntimeException {
	public HouseException() {}
	public HouseException(String msg) {
		super(msg);
	}
}

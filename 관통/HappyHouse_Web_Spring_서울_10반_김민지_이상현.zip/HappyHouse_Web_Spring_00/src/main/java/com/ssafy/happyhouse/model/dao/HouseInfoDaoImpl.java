package com.ssafy.happyhouse.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import com.ssafy.happyhouse.model.dto.HouseDealDto;
import com.ssafy.happyhouse.model.dto.HouseInfoDto;
import com.ssafy.happyhouse.utll.DBUtil;



/*
 * img + 위도 + 경도
 * 동코드, 동이름 ,아파트이름 join 후 정보출력
 * 
 */
public class HouseInfoDaoImpl implements HouseInfoDao{
	private HouseInfoDto houseInfoDto;
	private int size;
	private List<HouseInfoDto> search;
	public HouseInfoDaoImpl() {}
	
	@Override
	public List<HouseInfoDto> searchAllHouseInfo() throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder(100);
			sql.append(" select * from houseinfo");

			stmt = con.prepareStatement(sql.toString());
			rs = stmt.executeQuery();
			
			List<HouseInfoDto> list = new LinkedList<HouseInfoDto>();
			while (rs.next()) {
				HouseInfoDto deal = new HouseInfoDto();
				deal.setNo(rs.getInt("no"));
				deal.setDong(rs.getString("dong"));
				deal.setAptName(rs.getString("aptName"));
				deal.setCode(rs.getInt("code"));
				deal.setBuildYear(rs.getInt("buildYear"));
				deal.setJibun(rs.getString("jibun"));
//				if(rs.getString("lat")!=null) {
//					deal.setLat(rs.getString("lat"));
//				}
//				if(rs.getString("lng")!=null) {
//					deal.setLng(rs.getString("lng"));
//				}
				list.add(deal);
			}
			return list;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	@Override
	public HouseInfoDto search(int no) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from houseinfo where no = ? ";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, no);
			
			rs = stmt.executeQuery();
			if (rs.next()) {
				HouseInfoDto deal = new HouseInfoDto();
				deal.setNo(rs.getInt("no"));
				deal.setDong(rs.getString("dong"));
				deal.setAptName(rs.getString("aptName"));
				deal.setCode(rs.getInt("code"));
				deal.setBuildYear(rs.getInt("buildYear"));
				deal.setJibun(rs.getString("jibun"));
//				if(rs.getString("lat")!=null) {
//					deal.setLat(rs.getString("lat"));
//				}
//				if(rs.getString("lng")!=null) {
//					deal.setLng(rs.getString("lng"));
//				}
				return deal;
			}
			return null;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}
	
	@Override
	public List<HouseDealDto> searchInfoToDeal(int no) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder(1000);
			sql.append("select d.no, d.dong, d.AptName, d.code, d.dealAmount, d.buildYear, d.dealYear, d.dealMonth, d.dealDay, d.area, d.floor, d.jibun, d.type, d.rentMoney ")
				.append("from (select * from houseinfo where no= ? ) i ")
				.append("join housedeal as d ")
				.append("where (d.dong = i.dong and d.aptname = i.aptname and d.code = i.code) ");

			stmt = con.prepareStatement(sql.toString());
			stmt.setInt(1, no);
			rs = stmt.executeQuery();
			
			List<HouseDealDto> list = new LinkedList<HouseDealDto>();
			while (rs.next()) {
				HouseDealDto deal = new HouseDealDto();
				deal.setNo(rs.getInt("no"));
				deal.setDong(rs.getString("dong"));
				deal.setAptName(rs.getString("aptName"));
				deal.setCode(rs.getInt("code"));
				deal.setDealAmount(rs.getString("dealAmount"));
				deal.setBuildYear(rs.getInt("buildYear"));
				deal.setDealYear(rs.getInt("dealYear"));
				deal.setDealMonth(rs.getInt("dealMonth"));
				deal.setDealDay(rs.getInt("dealDay"));
				deal.setArea(rs.getDouble("area"));
				deal.setFloor(rs.getInt("floor"));
				deal.setJibun(rs.getString("jibun"));
				deal.setType(rs.getString("type"));
				deal.setRentMoney(rs.getString("rentMoney"));
//				File[] fileList = new File("img").listFiles();   //img내부의 파일 읽기ㅇ
//				for (File file : fileList) {
//					if(file.isFile()) {
//						String fileName = file.getName();
//						String[] filesplit =fileName.split("\\.");   //{이름, 확장자}로 나눔
//						if(deal.getAptName().contains(filesplit[0])) {
//							deal.setImg("../img/"+fileName);
//							System.out.println(fileName);
//							break;
//		               }
//		            }
//		         }
				list.add(deal);
			}
			return list;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}
	
	@Override
	public HouseInfoDto searchDealToInfo(int no) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder(1000);
			sql.append("select i.no, i.dong, i.AptName, i.code, i.buildYear, i.jibun ")
				.append("from (select * from housedeal where no= ? ) d ")
				.append("join houseinfo as i ")
				.append("where (d.dong = i.dong and d.aptname = i.aptname and d.code = i.code) ");

			stmt = con.prepareStatement(sql.toString());
			stmt.setInt(1, no);
			rs = stmt.executeQuery();
			
			HouseInfoDto info = new HouseInfoDto();
			while (rs.next()) {
				info.setNo(rs.getInt("no"));
				info.setDong(rs.getString("dong"));
				info.setAptName(rs.getString("aptName"));
				info.setCode(rs.getInt("code"));
				info.setBuildYear(rs.getInt("buildYear"));
				info.setJibun(rs.getString("jibun"));
				/*이미지 설정*/
			}
			return info;
			
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		
	}
	
	public static void main(String[] args) {
		HouseInfoDao dao = new HouseInfoDaoImpl();
		List<HouseInfoDto> infolist = new LinkedList<HouseInfoDto>();
		List<HouseDealDto> deallist = new LinkedList<HouseDealDto>();
		
		System.out.println("=============HouseSearchAll=============");
		try {
			infolist = dao.searchAllHouseInfo();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (HouseInfoDto i : infolist) {
			System.out.println(i);
		}
		System.out.println("========================================");
		
		System.out.println("=============Search=============");
		try {
			HouseInfoDto info = dao.search(1);
			System.out.println(info);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("================================");
		
		System.out.println("=============Deal->Info data=============");
		try {
			HouseInfoDto info = dao.searchDealToInfo(1);
			System.out.println(info);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("=========================================");

		System.out.println("=============Info->Deal data=============");
		try {
			deallist = dao.searchInfoToDeal(1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (HouseDealDto d : deallist) {
			System.out.println(d);
		}
		System.out.println("=========================================");
	}
}
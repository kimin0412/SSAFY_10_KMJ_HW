package com.ssafy.happyhouse.model.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.dto.HouseMemberDto;

/**
 * DAO (Data Access Object)
 *	- data를 insert, delete, update, select하는 기능의 객체
 */
@Mapper
public interface HouseMemberDao {
	public List<HouseMemberDto> searchAll() 	throws SQLException;
	public HouseMemberDto search(String id) 	throws SQLException;
	public HouseMemberDto searchId(HouseMemberDto houseMember) 	throws SQLException;
	public HouseMemberDto searchPwd(HouseMemberDto houseMember) throws Exception;
	public int remove(String id) 				throws SQLException;
	public int add(HouseMemberDto houseMemberDto) 		throws SQLException;
	public int update(HouseMemberDto houseMemberDto) 	throws SQLException;
}

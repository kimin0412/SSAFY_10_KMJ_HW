package com.ssafy.happyhouse.model.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.happyhouse.model.dto.HouseMemberDto;


@Repository
public class HouseMemberDaoImpl implements HouseMemberDao {
	
	@Autowired
	SqlSession sqlSession;

	@Override
	public List<HouseMemberDto> searchAll() throws SQLException {
		return sqlSession.selectList("housemember.searchAll");
	}

	@Override
	public HouseMemberDto search(String id) throws SQLException {
		return sqlSession.selectOne("housemember.search", id);
	}

	@Override
	public HouseMemberDto searchId(HouseMemberDto houseMember) throws SQLException {
		return sqlSession.selectOne("housemember.searchId", houseMember);
	}

	@Override
	public HouseMemberDto searchPwd(HouseMemberDto houseMember) throws Exception {
		return sqlSession.selectOne("housemember.searchPwd", houseMember);
	}

	@Override
	public int remove(String id) throws SQLException {
		return sqlSession.delete("housemember.remove", id);
	}

	@Override
	public int add(HouseMemberDto houseMemberDto) throws SQLException {
		return sqlSession.insert("housemember.insert", houseMemberDto);
	}

	@Override
	public int update(HouseMemberDto houseMemberDto) throws SQLException {
		return sqlSession.update("housemember.add", houseMemberDto);	
	}
	
}

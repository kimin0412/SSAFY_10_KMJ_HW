package com.ssafy.happyhouse.model.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.model.dto.ShopInfoDto;

/**
 * DAO (Data Access Object)
 *	- data를 insert, delete, update, select하는 기능의 객체
 */

public interface ShopInfoDao {
	public List<ShopInfoDto> searchAll(int currentPage, int sizePerPage, String key, String word) 		throws SQLException;
	public ShopInfoDto search(int no) 			throws SQLException;
	public void remove(int no) 				throws SQLException;
	public void add(ShopInfoDto shopInfoDto) 		throws SQLException;
	public void update(ShopInfoDto shopInfoDto) 	throws SQLException;
	public int getTotalCount(String key, String word) throws SQLException;
}

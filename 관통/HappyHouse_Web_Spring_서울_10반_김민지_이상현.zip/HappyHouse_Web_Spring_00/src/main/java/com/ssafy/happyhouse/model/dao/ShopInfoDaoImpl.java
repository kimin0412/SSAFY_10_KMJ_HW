package com.ssafy.happyhouse.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.happyhouse.model.dto.ShopInfoDto;
import com.ssafy.happyhouse.model.service.ShopInfoService;
import com.ssafy.happyhouse.model.service.ShopInfoServiceImpl;
import com.ssafy.happyhouse.utll.DBUtil;



public class ShopInfoDaoImpl implements ShopInfoDao {
	
	@Override
	public List<ShopInfoDto> searchAll(int currentPage, int sizePerPage, String key, String word) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<ShopInfoDto> list = new ArrayList<ShopInfoDto>();
		
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append(" select * ");
			sql.append(" from shopinfo ");
			sql.append(" where 1=1");
			if(!key.equals("")) {
				sql.append(" and "+key+" LIKE ? ");
			}
			sql.append(" order by no desc \n ");
			sql.append(" limit ?, ? \n ");
			System.out.println(sql.toString());
			pstmt = con.prepareStatement(sql.toString());
			int idx=0;
			if(!key.equals("")) {
				pstmt.setString(++idx, "%"+word+"%");
			}
			pstmt.setInt(++idx, (currentPage - 1) * sizePerPage);
			pstmt.setInt(++idx, sizePerPage);
			
			System.out.println(pstmt.toString());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				list.add(new ShopInfoDto(rs.getInt(1), 
									rs.getString(2), 
									rs.getString(3), 
									rs.getString(4), 
									rs.getString(5), 
									rs.getString(6), 
									rs.getString(7), 
									rs.getString(8), 
									rs.getString(9), 
									rs.getString(10), 
									rs.getString(11), 
									rs.getString(12), 
									rs.getString(13), 
									rs.getString(14), 
									rs.getString(15), 
									rs.getString(16), 
									rs.getString(17), 
									rs.getString(18), 
									rs.getString(19), 
									rs.getString(20), 
									rs.getString(21), 
									rs.getString(22), 
									rs.getString(23)));
			}
//			try 구문에서 return이 있더라도 finally 수행한다.
//			JVM sys.exit같이 강제종료 아닌이상 finally 수행함.
			return list;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
	}

	@Override
	public ShopInfoDto search(int no) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ShopInfoDto shopInfo = null;
		
		try {
			con = DBUtil.getConnection();
			String sql = " select * from shopinfo where no = ? ";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, no);
			rs = stmt.executeQuery();
//			포인터 이동
//			데이터가 없는 경우 고려
			if(rs.next()) {
				shopInfo =new ShopInfoDto(rs.getInt(1), 
									rs.getString(2), 
									rs.getString(3), 
									rs.getString(4), 
									rs.getString(5), 
									rs.getString(6), 
									rs.getString(7), 
									rs.getString(8), 
									rs.getString(9), 
									rs.getString(10), 
									rs.getString(11), 
									rs.getString(12), 
									rs.getString(13), 
									rs.getString(14), 
									rs.getString(15), 
									rs.getString(16), 
									rs.getString(17), 
									rs.getString(18), 
									rs.getString(19), 
									rs.getString(20), 
									rs.getString(21), 
									rs.getString(22), 
									rs.getString(23));
			}
//			try 구문에서 return이 있더라도 finally 수행한다.
//			JVM sys.exit같이 강제종료 아닌이상 finally 수행함.
			return shopInfo;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	@Override
	public void remove(int no) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		
		try {
			con = DBUtil.getConnection();
			String sql = "DELETE FROM shopinfo WHERE no = ?";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, no);
			int rows = stmt.executeUpdate();
			
			if(rows>0) {
				System.out.println("삭제 완료");
			}
			else {
				System.out.println("삭제 못함");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	@Override
	public void add(ShopInfoDto shopInfo) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		
		try {
			con = DBUtil.getConnection();
			String sql = "INSERT INTO shopinfo (no, shopname,"
					+ "localname,code1,codename1,code2,codename2,code3,codename3,code4,codename4,citycode"
					+ ",city,gucode,gu,dongcode,dong,jibunaddress,address,oldpostcode,postcode,lng,lat) "
					+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, shopInfo.getNo());
			stmt.setString(2, shopInfo.getShopname());
			stmt.setString(3, shopInfo.getLocalname());
			stmt.setString(4, shopInfo.getCode1());
			stmt.setString(5, shopInfo.getCodename1());
			stmt.setString(6, shopInfo.getCode2());
			stmt.setString(7, shopInfo.getCodename2());
			stmt.setString(8, shopInfo.getCode3());
			stmt.setString(9, shopInfo.getCodename3());
			stmt.setString(10, shopInfo.getCode4());
			stmt.setString(11, shopInfo.getCodename4());
			stmt.setString(12, shopInfo.getCitycode());
			stmt.setString(13, shopInfo.getCity());
			stmt.setString(14, shopInfo.getGucode());
			stmt.setString(15, shopInfo.getGu());
			stmt.setString(16, shopInfo.getDongcode());
			stmt.setString(17, shopInfo.getDong());
			stmt.setString(18, shopInfo.getJibunaddress());
			stmt.setString(19, shopInfo.getAddress());
			stmt.setString(20, shopInfo.getOldpostcode());
			stmt.setString(21, shopInfo.getPostcode());
			stmt.setString(22, shopInfo.getLng());
			stmt.setString(23, shopInfo.getLat());
			int rows = stmt.executeUpdate();
			
			if(rows>0) {
				System.out.println("추가 완료");
			}
			else {
				System.out.println("추가 못함");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	@Override
	public void update(ShopInfoDto shopInfo) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			String sql = "UPDATE shopinfo SET shopname = ?, localname = ?,code1 = ?, codename1 = ?,"
					+ "code2 = ?, codename2 = ?,code3 = ?,codename3 = ?,code4 = ?,"
					+ "codename4   = ?," + 
					"citycode    = ?," + 
					"city = ?," + 
					"gucode = ?," + 
					"gu = ?," + 
					"dongcode = ?," + 
					"dong = ?," + 
					"jibunaddress = ?," + 
					"address = ?," + 
					"oldpostcode = ?," + 
					"postcode = ?," + 
					"lng = ?," + 
					"lat = ?" + "WHERE no = ?";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, shopInfo.getShopname());
			stmt.setString(2, shopInfo.getLocalname());
			stmt.setString(3, shopInfo.getCode1());
			stmt.setString(4, shopInfo.getCodename1());
			stmt.setString(5, shopInfo.getCode2());
			stmt.setString(6, shopInfo.getCodename2());
			stmt.setString(7, shopInfo.getCode3());
			stmt.setString(8, shopInfo.getCodename3());
			stmt.setString(9, shopInfo.getCode4());
			stmt.setString(10, shopInfo.getCodename4());
			stmt.setString(11, shopInfo.getCitycode());
			stmt.setString(12, shopInfo.getCity());
			stmt.setString(13, shopInfo.getGucode());
			stmt.setString(14, shopInfo.getGu());
			stmt.setString(15, shopInfo.getDongcode());
			stmt.setString(16, shopInfo.getDong());
			stmt.setString(17, shopInfo.getJibunaddress());
			stmt.setString(18, shopInfo.getAddress());
			stmt.setString(19, shopInfo.getOldpostcode());
			stmt.setString(20, shopInfo.getPostcode());
			stmt.setString(21, shopInfo.getLng());
			stmt.setString(22, shopInfo.getLat());
			stmt.setInt(23, shopInfo.getNo());
			int rows = stmt.executeUpdate();
			
			if(rows>0) {
				System.out.println("업데이트 완료");
			}
			else {
				System.out.println("업데이트 못함");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}

	}
	
	@Override
	public int getTotalCount(String key, String word) throws SQLException {
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select count(no) \n");
			sql.append("from shopinfo \n");
			if(!word.isEmpty()) {
				if("shopname".equals(key)) {
					sql.append("where shopname like ? \n");
				} else {
					sql.append("where " + key + " like ? \n");
				}
			}
			sql.append("order by no desc \n");
			System.out.println(sql);
			pstmt = conn.prepareStatement(sql.toString());
			if(!word.isEmpty()) {
				if("shopname".equals(key))
					pstmt.setString(1, "%" + word + "%");
				else
					pstmt.setString(1, "%" + word + "%");
			}
			System.out.println(pstmt.toString());
			rs = pstmt.executeQuery();
			rs.next();
			cnt = rs.getInt(1);
			System.out.println("검색 갯수:"+cnt);
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return cnt;
	}
	
	
	public static void main(String[] args) {
		ShopInfoDao dao = new ShopInfoDaoImpl();
		List<ShopInfoDto> shopInfos;
//		try {
//			shopInfos = dao.searchAll();
//			for (ShopInfoDto info : shopInfos) {
//				System.out.println(info);
//			}
//		} catch (SQLException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
		ShopInfoService ss = new ShopInfoServiceImpl();
		ss.add(new ShopInfoDto(11119999,"테스트", "테스트점", "T","테스트음식","Q06","테스트식",
				"Q06A01",	"정통양식/경양식",	"I56114",	
				"서양식 음식점업",	"11",	"서울특별시",	"11110",	"종로구",	
				"1111013800",	"종로2가",	"서울특별시 종로구 종로2가 21",
				"서울특별시 종로구 종로 85",	"110122",	"3164",	
				"126.986960548296",	"37.5704220461144"));
		System.out.println(ss.search(11119999));
		ss.remove(11119999);
	}

}

package com.ssafy.happyhouse.model.repo;

import java.util.List;

import com.ssafy.happyhouse.model.dto.HouseInfoDto;
import com.ssafy.happyhouse.model.dto.HousePageBean;

public interface HouseRepo {
	public List<HouseInfoDto> searchAll();
	
	public HouseInfoDto searchDong(String dong);
	
	public HouseInfoDto searchAptName(String AptName);
	
	public List<HouseInfoDto> searchAllBean(HousePageBean bean);
	
}

package com.ssafy.happyhouse.model.repo;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.happyhouse.model.dto.HouseInfoDto;
import com.ssafy.happyhouse.model.dto.HousePageBean;

@Repository
public class HouseRepoImpl implements HouseRepo{
	@Autowired
	SqlSession session;
	
	private final String ns="com.ssafy.haooyhouse.mapper.house.";

	@Override
	public List<HouseInfoDto> searchAll() {
		return session.selectList(ns+"searchAll");
	}

	@Override
	public HouseInfoDto searchDong(String dong) {
		return session.selectOne(ns+"searchDong",dong);
	}

	@Override
	public HouseInfoDto searchAptName(String AptName) {
		return session.selectOne(ns+"searchAptName", AptName);
	}

	@Override
	public List<HouseInfoDto> searchAllBean(HousePageBean bean) {
		return session.selectList(ns+"searchAllBean",bean);
	}
}

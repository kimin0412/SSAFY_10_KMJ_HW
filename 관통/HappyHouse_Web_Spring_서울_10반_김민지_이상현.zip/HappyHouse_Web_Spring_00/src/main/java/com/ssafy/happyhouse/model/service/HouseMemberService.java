package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.model.dto.HouseMemberDto;

public interface HouseMemberService {
	/** id에 해당하는 회원 정보를 추출하는 기능*/
	public HouseMemberDto search(String id);
	public HouseMemberDto searchId(HouseMemberDto dto);
	public HouseMemberDto searchPwd(HouseMemberDto dto);
	public List<HouseMemberDto> searchAll();
	
	/** 회원 인증을 위해 id와 비밀번호가 맞는지 확인하는 기능*/
	public int check(HouseMemberDto dto);
	
	/** 회원 가입 시 동일한id가 있는지 검사하는 기능*/
	public int checkId(HouseMemberDto dto);
	
	/** 회원 등록하는 기능
	 * @throws Exception 
	 * @throws SQLException */
	public int add(HouseMemberDto housememberDto) throws Exception;
	public int update(HouseMemberDto housememberDto) throws Exception;
	public void remove(String id);
	
//	public int check(UserDto dto);
}

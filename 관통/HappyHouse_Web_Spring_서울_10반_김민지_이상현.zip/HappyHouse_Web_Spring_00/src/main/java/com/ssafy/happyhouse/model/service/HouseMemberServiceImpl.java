package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.mapper.HouseMemberMapper;
import com.ssafy.happyhouse.model.dto.HouseMemberDto;

@Service
public class HouseMemberServiceImpl implements HouseMemberService {

	@Autowired
	private HouseMemberMapper mapper;

	@Override
	public HouseMemberDto search(String id) {
		return mapper.search(id);
	}

	@Override
	public List<HouseMemberDto> searchAll() {
		return mapper.searchAll();
	}

	@Override
	public int check(HouseMemberDto dto) {
		return mapper.check(dto);
	}

	@Override
	public HouseMemberDto searchId(HouseMemberDto dto) {
		System.out.println("!!!!!!!!!");
		return mapper.searchId(dto);
	}

	@Override
	public HouseMemberDto searchPwd(HouseMemberDto dto) {
		return mapper.searchPwd(dto);
	}

	@Override
	public int checkId(HouseMemberDto dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int add(HouseMemberDto housememberDto) throws Exception {
		return mapper.add(housememberDto);
	}

	@Override
	public int update(HouseMemberDto housememberDto) throws Exception {
		return mapper.update(housememberDto);
	}

	@Override
	public void remove(String id) {
		mapper.remove(id);
	}

}

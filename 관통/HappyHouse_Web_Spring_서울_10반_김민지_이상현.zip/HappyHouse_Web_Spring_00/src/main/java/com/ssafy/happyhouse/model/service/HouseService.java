package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.dto.HouseInfoDto;
import com.ssafy.happyhouse.model.dto.HousePageBean;

public interface HouseService {
	public List<HouseInfoDto> searchAll();
	
	public HouseInfoDto searchDong(String dong);
	
	public HouseInfoDto searchAptName(String AptName);
	
	public List<HouseInfoDto> searchAllBean(HousePageBean bean);
}

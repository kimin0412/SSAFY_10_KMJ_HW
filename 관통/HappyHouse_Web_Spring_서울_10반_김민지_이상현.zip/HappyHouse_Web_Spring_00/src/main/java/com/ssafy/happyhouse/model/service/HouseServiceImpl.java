package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.dto.HouseInfoDto;
import com.ssafy.happyhouse.model.dto.HousePageBean;
import com.ssafy.happyhouse.model.repo.HouseRepo;

@Service
public class HouseServiceImpl implements HouseService{
	@Autowired
	HouseRepo repo;

	@Override
	public List<HouseInfoDto> searchAll() {
		return repo.searchAll();
	}

	@Override
	public HouseInfoDto searchDong(String dong) {
		return repo.searchDong(dong);
	}

	@Override
	public HouseInfoDto searchAptName(String AptName) {
		return repo.searchAptName(AptName);
	}

	@Override
	public List<HouseInfoDto> searchAllBean(HousePageBean bean) {
		return repo.searchAllBean(bean);
	}
	
	
}





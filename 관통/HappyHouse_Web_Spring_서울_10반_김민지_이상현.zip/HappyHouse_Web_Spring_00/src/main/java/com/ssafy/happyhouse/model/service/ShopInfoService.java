package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.dto.ShopInfoDto;
import com.ssafy.happyhouse.utll.PageNavigation;

public interface ShopInfoService {
	/** search, searchall 기능*/
	public ShopInfoDto search(int no);
	public List<ShopInfoDto> searchAll(int currentPage, int sizePerPage, String key, String word);
	
	
	/** 추가, 업데이트, 제거 기능*/
	public void add(ShopInfoDto shopInfoDto);
	public void update(ShopInfoDto shopInfoDto);
	public void remove(int no);
	public PageNavigation makePageNavigation(int currentPage, int sizePerPage, String key, String word) throws Exception;
}

package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.model.dao.ShopInfoDao;
import com.ssafy.happyhouse.model.dao.ShopInfoDaoImpl;
import com.ssafy.happyhouse.model.dto.ShopInfoDto;
import com.ssafy.happyhouse.utll.PageNavigation;

public class ShopInfoServiceImpl implements ShopInfoService {
	
	private ShopInfoDao dao = new ShopInfoDaoImpl();

	@Override
	public ShopInfoDto search(int no) {
		try {
			return dao.search(no);
		} catch (SQLException e) {
			throw new HappyHouseException("정보 조회중 오류 발생");
		}
	}

	@Override
	public List<ShopInfoDto> searchAll(int currentPage, int sizePerPage, String key, String word) {
		try {
			return dao.searchAll(currentPage, sizePerPage, key, word);
		} catch (SQLException e) {
			throw new HappyHouseException("정보 조회중 오류 발생");
		}
	}

	@Override
	public void add(ShopInfoDto shopInfoDto) {
		try {
			dao.add(shopInfoDto);
		} catch (SQLException e) {
			throw new HappyHouseException("shop 정보 추가중 오류 발생");
		}
		
	}

	@Override
	public void update(ShopInfoDto shopInfoDto) {
		try {
			dao.update(shopInfoDto);
		} catch (SQLException e) {
			throw new HappyHouseException("shop 정보 업데이트 중 오류 발생");
		}
	}

	@Override
	public void remove(int no) {
		try {
			dao.remove(no);
		} catch (SQLException e) {
			throw new HappyHouseException("shop 정보 제거 중 오류 발생");
		}
	}

	@Override
	public PageNavigation makePageNavigation(int currentPage, int sizePerPage, String key, String word) throws Exception {
		PageNavigation pageNavigation = new PageNavigation();
		int naviSize = 8;	//페이지 갯수
		pageNavigation.setCurrentPage(currentPage);
		pageNavigation.setNaviSize(naviSize);
		int totalCount = dao.getTotalCount(key, word);	//총 게시글 수(?)
		pageNavigation.setTotalCount(totalCount);
		int totalPageCount = (totalCount-1)/sizePerPage+1;	//총 페이지 수(?)
		pageNavigation.setTotalPageCount(totalPageCount);
		boolean startRange = currentPage<=naviSize;	//startRange {true : 이전x, false : 이전o}
		pageNavigation.setStartRange(startRange);
		boolean endRange = (totalPageCount-1)/naviSize * naviSize < currentPage;	//endRange {true : 다음x, false : 다음o}
		pageNavigation.setEndRange(endRange);
		pageNavigation.makeNavigator();
		return pageNavigation;
	}
}

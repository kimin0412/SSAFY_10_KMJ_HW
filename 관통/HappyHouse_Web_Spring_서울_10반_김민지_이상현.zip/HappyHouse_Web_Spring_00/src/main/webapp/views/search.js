let search="전체";

$(".c1").on("click", ()=>{
	$("#cat").html('전체<span class="caret"></span>');
	search = "전체";
	$("#stype").val("all");
	console.log("${food}");
});
$(".c2").on("click", ()=>{
	$("#cat").html('법정동<span class="caret"></span>');
	search = "법정동";
	$("#stype").val("dong");
});
$(".c3").on("click", ()=>{
	$("#cat").html('이름<span class="caret"></span>');
	search = "이름";
	$("#stype").val("AptName");
});

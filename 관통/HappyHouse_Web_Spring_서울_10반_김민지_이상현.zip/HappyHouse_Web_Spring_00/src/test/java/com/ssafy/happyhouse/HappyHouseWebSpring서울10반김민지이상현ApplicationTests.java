package com.ssafy.happyhouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HappyHouseWebSpring서울10반김민지이상현ApplicationTests {

	@Test
	void contextLoads() {
	}

}
